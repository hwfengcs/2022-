import pandas as pd
import numpy as np
import seaborn as sns
from matplotlib import pyplot as plt
from matplotlib import cm
from pylab import *
from matplotlib.font_manager import FontProperties
from matplotlib.collections import LineCollection
from mpl_toolkits.axes_grid1.inset_locator import mark_inset
from mpl_toolkits.axes_grid1.inset_locator import inset_axes
plt.rcParams['font.sans-serif']=['SimHei']
plt.rcParams['axes.unicode_minus'] = False

""" ==================== 导入数据 ===================="""
df = pd.read_csv("D:/3、竞赛/新建文件夹/sheet2.csv")


""" ==================== 五、特征工程 ==================== """
""" =============== 5.1.1 数据特征观测 =============== """
""" ========== 正态性检验 ========== """
from scipy.stats import kstest
print(kstest(df.iloc[:,6], cdf = "norm"))
print(kstest(df.iloc[:,7], cdf = "norm"))
print(kstest(df.iloc[:,8], cdf = "norm"))
print(kstest(df.iloc[:,9], cdf = "norm"))
print(kstest(df.iloc[:,10], cdf = "norm"))
print(kstest(df.iloc[:,11], cdf = "norm"))
print(kstest(df.iloc[:,12], cdf = "norm"))
print(kstest(df.iloc[:,13], cdf = "norm"))
print(kstest(df.iloc[:,14], cdf = "norm"))
print(kstest(df.iloc[:,15], cdf = "norm"))
print(kstest(df.iloc[:,16], cdf = "norm"))
print(kstest(df.iloc[:,17], cdf = "norm"))
print(kstest(df.iloc[:,18], cdf = "norm"))
print(kstest(df.iloc[:,19], cdf = "norm"))

""" =============== 相关图 =============== """
spearman_data = pd.DataFrame(df.iloc[:, 6:20]).corr(method='spearman')
ax = sns.heatmap(spearman_data,
                 vmax = 1,
                 cmap = 'seismic',
                 annot = True)
ax.set_title('Spearman热力相关图', fontsize = 15)
plt.show()

""" =============== 填充颜色的缺失值 =============== """
def cos_sim(np1, np2): # 余弦相似度函数
    return np1.dot(np2) / (np.linalg.norm(np1) * np.linalg.norm(np2))

def fill_color(data, index, a_):
    a = data[data["文物编号"]==index].iloc[:,10:]
    c = []
    for i in range(len(data)):
        b = data.iloc[i, 10:]
        if i in a_:
            continue
        else:
            c.append(cos_sim(np.array(a), np.array(b))[0])
    r = c.copy()
    r.sort()
    return data.iloc[c.index(r[-1])][0],data.iloc[c.index(r[-1])][3],r[-1]
    
data1 = df[(df["纹饰_"] == "A") & (df["类型_"] == "铅钡") & (df["表面风化_"] == "风化")]
print(fill_color(data1, 19, [1, 8]))
print(fill_color(data1, 48, [1, 8]))
data2 = df[(df["纹饰_"] == "C") & (df["类型_"] == "铅钡") & (df["表面风化_"] == "风化")]
print(fill_color(data2, 40, [10, 21]))
print(fill_color(data2, 58, [10, 21]))

""" =============== 散点图=============== """
plt.figure()
p = plt.subplot(projection = "3d")
p.scatter(df[df["表面风化"]==0].iloc[:, 5], 
          df[df["表面风化"]==0].iloc[:, 6], 
          df[df["表面风化"]==0].iloc[:, 7], 
          label = "无风化",
          marker = "+", s = 30)
p.scatter(df[df["表面风化"]==1].iloc[:, 5], 
          df[df["表面风化"]==1].iloc[:, 6], 
          df[df["表面风化"]==1].iloc[:, 7], 
          label = "风化",
          marker = "x", s = 30)
p.set_xlabel("纹饰", fontdict={'family': 'Kaiti', 'size': 15})
p.set_ylabel("类型", fontdict={'family': 'Kaiti', 'size': 15})
p.set_zlabel("颜色", fontdict={'family': 'Kaiti', 'size': 15})
plt.legend()
plt.show()

""" =============== Fisher精确检验和卡方检验 =============== """
import scipy
a0 = len(df[(df["纹饰"] == 1) & (df["表面风化"] == 0)])
a1 = len(df[(df["纹饰"] == 1) & (df["表面风化"] == 1)])
b0 = len(df[(df["纹饰"] == 2) & (df["表面风化"] == 0)])
b1 = len(df[(df["纹饰"] == 2) & (df["表面风化"] == 1)])
c0 = len(df[(df["纹饰"] == 3) & (df["表面风化"] == 0)])
c1 = len(df[(df["纹饰"] == 3) & (df["表面风化"] == 1)])
scipy.stats.chi2_contingency([[a0,a1],[b0,b1],[c0,c1]])

a0 = len(df[(df["类型"] == 0) & (df["表面风化"] == 0)])
a1 = len(df[(df["类型"] == 0) & (df["表面风化"] == 1)])
b0 = len(df[(df["类型"] == 1) & (df["表面风化"] == 0)])
b1 = len(df[(df["类型"] == 1) & (df["表面风化"] == 1)])
scipy.stats.fisher_exact([[a0,a1],[b0,b1]])

a0 = len(df[(df["颜色"] == 1) & (df["表面风化"] == 0)])
a1 = len(df[(df["颜色"] == 1) & (df["表面风化"] == 1)])
b0 = len(df[(df["颜色"] == 2) & (df["表面风化"] == 0)])
b1 = len(df[(df["颜色"] == 2) & (df["表面风化"] == 1)])
c0 = len(df[(df["颜色"] == 3) & (df["表面风化"] == 0)])
c1 = len(df[(df["颜色"] == 3) & (df["表面风化"] == 1)])
d0 = len(df[(df["颜色"] == 4) & (df["表面风化"] == 0)])
d1 = len(df[(df["颜色"] == 4) & (df["表面风化"] == 1)])
e0 = len(df[(df["颜色"] == 5) & (df["表面风化"] == 0)])
e1 = len(df[(df["颜色"] == 5) & (df["表面风化"] == 1)])
f0 = len(df[(df["颜色"] == 6) & (df["表面风化"] == 0)])
f1 = len(df[(df["颜色"] == 6) & (df["表面风化"] == 1)])
g0 = len(df[(df["颜色"] == 7) & (df["表面风化"] == 0)])
g1 = len(df[(df["颜色"] == 7) & (df["表面风化"] == 1)])
h0 = len(df[(df["颜色"] == 8) & (df["表面风化"] == 0)])
h1 = len(df[(df["颜色"] == 8) & (df["表面风化"] == 1)])
scipy.stats.chi2_contingency([[a0,a1],[b0,b1],[c0,c1],[d0,d1],[e0,e1],[f0,f1],[g0,g1],[h0,h1]])

""" =============== spearman秩相关检验 =============== """
import scipy

scipy.stats.spearmanr(df["表面风化"], df["纹饰"])
scipy.stats.spearmanr(df["表面风化"], df["类型"])
scipy.stats.spearmanr(df["表面风化"], df["颜色"])

""" =============== Apriori关联分析 =============== """
df_apr = df.iloc[:, 1:5]
from apyori import apriori
relus = apriori(np.array(df.iloc[:, 1:5]),
                min_support = 0.1,
                min_confidence = 0.7)
results = list(relus)

supports=[]
confidences=[]
lifts=[]
bases=[]
adds=[]

for r in results:
    for x in r.ordered_statistics:
        supports.append(r.support)
        confidences.append(x.confidence)
        lifts.append(x.lift)
        bases.append(list(x.items_base))
        adds.append(list(x.items_add))

result = pd.DataFrame({
    'support':supports,
    'confidence':confidences,
    'lift':lifts,
    'base':bases,
    'add':adds
})

""" =============== 利用风化后的预测风化前的 =============== """
from sklearn.preprocessing import PowerTransformer
pt_00 = PowerTransformer().fit(df[(df["类型"]==0) & (df["采样点风化"]==0)].iloc[:,10:])
pt_01 = PowerTransformer().fit(df[(df["类型"]==0) & (df["采样点风化"]==1)].iloc[:,10:])
pt_10 = PowerTransformer().fit(df[(df["类型"]==1) & (df["采样点风化"]==0)].iloc[:,10:])
pt_11 = PowerTransformer().fit(df[(df["类型"]==1) & (df["采样点风化"]==1)].iloc[:,10:])
pt_12 = PowerTransformer().fit(df[(df["类型"]==1) & (df["采样点风化"]==2)].iloc[:,10:])

#　高钾
name = []
ks1 = []
pv1 = []
ks2 = []
pv2 = []
ks3 = []
pv3 = []
plt.figure()
for i in [0,2,3,4,5,6,7,10]:
    index = [0,2,3,4,5,6,7,10].index(i)
    plt.subplot(2, 4, index+1)
    sns.kdeplot(df[(df["类型"]==0) & (df["采样点风化"]==0)].iloc[:, i+10], label = "无风化{}含量".format(df.columns[i+10]), shade = False)
    sns.kdeplot(df[(df["类型"]==0) & (df["采样点风化"]==1)].iloc[:, i+10], label = "风化{}含量".format(df.columns[i+10]), shade = False)
    sns.kdeplot(pt_00.transform(df[(df["类型"]==0) & (df["采样点风化"]==0)].iloc[:,10:])[:,i], label = "无风化{}变换后含量".format(df.columns[i+10]), shade = False)
    sns.kdeplot(pt_01.transform(df[(df["类型"]==0) & (df["采样点风化"]==1)].iloc[:,10:])[:,i], label = "风化{}变换后含量".format(df.columns[i+10]), shade = False)
    plt.legend()
    name.append(df.columns[i+10])
    ks1.append(kstest(pt_00.transform(df[(df["类型"]==0) & (df["采样点风化"]==0)].iloc[:,10:])[:,i], cdf = "norm")[0])
    pv1.append(kstest(pt_00.transform(df[(df["类型"]==0) & (df["采样点风化"]==0)].iloc[:,10:])[:,i], cdf = "norm")[1])
    ks2.append(kstest(pt_01.transform(df[(df["类型"]==0) & (df["采样点风化"]==1)].iloc[:,10:])[:,i], cdf = "norm")[0])
    pv2.append(kstest(pt_01.transform(df[(df["类型"]==0) & (df["采样点风化"]==1)].iloc[:,10:])[:,i], cdf = "norm")[1])
    ks3.append(kstest(pt_00.transform(df[(df["类型"]==0) & (df["采样点风化"]==0)].iloc[:,10:])[:,i], 
                      pt_01.transform(df[(df["类型"]==0) & (df["采样点风化"]==1)].iloc[:,10:])[:,i])[0])
    pv3.append(kstest(pt_00.transform(df[(df["类型"]==0) & (df["采样点风化"]==0)].iloc[:,10:])[:,i], 
                      pt_01.transform(df[(df["类型"]==0) & (df["采样点风化"]==1)].iloc[:,10:])[:,i])[1])
    
res = pd.DataFrame({"name":name, "ks1":ks1, "pv1":pv1, "ks2":ks2, "pv2":pv2, "ks3":ks3, "pv3":pv3})

def create_data(data):
    a = data.copy()
    for i in range(len(data.columns)):
        for j in range(i, len(data.columns)):
            a[data.columns[i] + "*" + data.columns[j]] = np.array(data.iloc[:, i]) * np.array(data.iloc[:, j])
    return a

x = create_data(df[(df["类型"]==0) & (df["采样点风化"]==0)].iloc[:, [10,12,13,14,15,16,17,20]])
y1 = df[(df["类型"]==0) & (df["采样点风化"]==0)].iloc[:, 11]
y2 = df[(df["类型"]==0) & (df["采样点风化"]==0)].iloc[:, 18]
y3 = df[(df["类型"]==0) & (df["采样点风化"]==0)].iloc[:, 19]
y4 = df[(df["类型"]==0) & (df["采样点风化"]==0)].iloc[:, 21]
y5 = df[(df["类型"]==0) & (df["采样点风化"]==0)].iloc[:, 22]
y6 = df[(df["类型"]==0) & (df["采样点风化"]==0)].iloc[:, 23]


xx = pd.DataFrame()
for i in range(len(df.iloc[:,10:].columns)):
    xx[df.iloc[:,10:].columns[i]] = pt_00.inverse_transform(pt_01.transform(df[(df["类型"]==0) & (df["采样点风化"]==1)].iloc[:,10:]))[:, i]
xx = create_data(xx.iloc[:, [0,2,3,4,5,6,7,10]])

import statsmodels.api as sm
lm1 = sm.OLS(y1,x.iloc[:, [0,2,3,4,5,7,10,12,16,17,18,23]]).fit()
lm1.summary()
lm2 = sm.OLS(y2,x.iloc[:, [0,4,5,6,11,13,19,24,25,30,31,36]]).fit()
lm2.summary()
lm3 = sm.OLS(y3,x.iloc[:, [1,3,7,8,13,16,20,22,29,30,31]]).fit()
lm3.summary()
lm4 = sm.OLS(y4,x.iloc[:, [12,41,28,18,25,22,38,0]]).fit()
lm4.summary()
lm5 = sm.OLS(y5,x.iloc[:, [0,1,2,3,11,13,15,18,22,36,40]]).fit()
lm5.summary()
lm6 = sm.OLS(y6,x.iloc[:, [1,2,6,7,8,9,10,14,25,36,41]]).fit()
lm6.summary()
result_q1_0 = pd.DataFrame({"SiO2":pt_00.inverse_transform(pt_01.transform(df[(df["类型"]==0) & (df["采样点风化"]==1)].iloc[:,10:]))[:, 0],
                            'Na2O':lm1.predict(xx.iloc[:, [0,2,3,4,5,7,10,12,16,17,18,23]]),
                            'K2O':pt_00.inverse_transform(pt_01.transform(df[(df["类型"]==0) & (df["采样点风化"]==1)].iloc[:,10:]))[:, 2],
                            'CaO':pt_00.inverse_transform(pt_01.transform(df[(df["类型"]==0) & (df["采样点风化"]==1)].iloc[:,10:]))[:, 3],
                            'MgO':pt_00.inverse_transform(pt_01.transform(df[(df["类型"]==0) & (df["采样点风化"]==1)].iloc[:,10:]))[:, 4],
                            'Al2O3':pt_00.inverse_transform(pt_01.transform(df[(df["类型"]==0) & (df["采样点风化"]==1)].iloc[:,10:]))[:, 5],
                            'Fe2O3':pt_00.inverse_transform(pt_01.transform(df[(df["类型"]==0) & (df["采样点风化"]==1)].iloc[:,10:]))[:, 6],
                            'CuO':pt_00.inverse_transform(pt_01.transform(df[(df["类型"]==0) & (df["采样点风化"]==1)].iloc[:,10:]))[:, 7],
                            'PbO':lm2.predict(xx.iloc[:, [0,4,5,6,11,13,19,24,25,30,31,36]]),
                            'BaO':lm3.predict(xx.iloc[:, [1,3,7,8,13,16,20,22,29,30,31]]),
                            'P2O5':pt_00.inverse_transform(pt_01.transform(df[(df["类型"]==0) & (df["采样点风化"]==1)].iloc[:,10:]))[:, 10],
                            'SrO':lm4.predict(xx.iloc[:, [12,41,28,18,12,25,22,38,0,38]]), 
                            'SnO2':lm5.predict(xx.iloc[:, [0,1,2,3,11,13,15,18,22,36,40]]),
                            'SO2':lm6.predict(xx.iloc[:, [1,2,6,7,8,9,10,14,25,36,41]])})
result_q1_0[result_q1_0 < 0] = 0
r_0 = pd.concat([df[(df["类型"]==0) & (df["采样点风化"]==1)].iloc[:, 0:10], result_q1_0],
                ignore_index = True,
                axis = 0)
r_0.to_csv("D:/3、竞赛/新建文件夹/q1_0.csv", encoding='utf_8_sig')
q1_r0 = pd.read_csv("D:/3、竞赛/新建文件夹/q1_0.csv")

name = []
ks1 = []
pv1 = []
ks2 = []
pv2 = []
ks3 = []
pv3 = []
ks4 = []
pv4 = []
ks5 = []
pv5 = []
ks6 = []
pv6 = []
plt.figure()
for i in range(14):
    plt.rcParams.update({"font.size":5})
    plt.subplot(2,7,i+1)
    sns.kdeplot(df[(df["类型"]==1) & (df["采样点风化"]==0)].iloc[:, i+10], label = "无风化{}含量".format(df.columns[i+10]), shade = False)
    sns.kdeplot(df[(df["类型"]==1) & (df["采样点风化"]==1)].iloc[:, i+10], label = "风化{}含量".format(df.columns[i+10]), shade = False)
    sns.kdeplot(df[(df["类型"]==1) & (df["采样点风化"]==2)].iloc[:, i+10], label = "严重风化风化{}含量".format(df.columns[i+10]), shade = False)
    sns.kdeplot(pt_10.transform(df[(df["类型"]==1) & (df["采样点风化"]==0)].iloc[:,10:])[:,i], label = "无风化{}转换后含量".format(df.columns[i+10]), shade = False)
    sns.kdeplot(pt_11.transform(df[(df["类型"]==1) & (df["采样点风化"]==1)].iloc[:,10:])[:,i], label = "风化{}转换后含量".format(df.columns[i+10]), shade = False)
    sns.kdeplot(pt_12.transform(df[(df["类型"]==1) & (df["采样点风化"]==2)].iloc[:,10:])[:,i], label = "严重风化{}转换后含量".format(df.columns[i+10]), shade = False)
    plt.legend()
    name.append(df.columns[i+10])
    ks1.append(kstest(pt_10.transform(df[(df["类型"]==1) & (df["采样点风化"]==0)].iloc[:,10:])[:,i], cdf = "norm")[0])
    pv1.append(kstest(pt_10.transform(df[(df["类型"]==1) & (df["采样点风化"]==0)].iloc[:,10:])[:,i], cdf = "norm")[1])
    ks2.append(kstest(pt_11.transform(df[(df["类型"]==1) & (df["采样点风化"]==1)].iloc[:,10:])[:,i], cdf = "norm")[0])
    pv2.append(kstest(pt_11.transform(df[(df["类型"]==1) & (df["采样点风化"]==1)].iloc[:,10:])[:,i], cdf = "norm")[1])
    ks3.append(kstest(pt_12.transform(df[(df["类型"]==1) & (df["采样点风化"]==2)].iloc[:,10:])[:,i], cdf = "norm")[0])
    pv3.append(kstest(pt_12.transform(df[(df["类型"]==1) & (df["采样点风化"]==2)].iloc[:,10:])[:,i], cdf = "norm")[1])
    ks4.append(kstest(pt_10.transform(df[(df["类型"]==1) & (df["采样点风化"]==0)].iloc[:,10:])[:,i], 
                      pt_11.transform(df[(df["类型"]==1) & (df["采样点风化"]==1)].iloc[:,10:])[:,i])[0])
    pv4.append(kstest(pt_10.transform(df[(df["类型"]==1) & (df["采样点风化"]==0)].iloc[:,10:])[:,i], 
                      pt_11.transform(df[(df["类型"]==1) & (df["采样点风化"]==1)].iloc[:,10:])[:,i])[1])
    ks5.append(kstest(pt_10.transform(df[(df["类型"]==1) & (df["采样点风化"]==0)].iloc[:,10:])[:,i], 
                      pt_12.transform(df[(df["类型"]==1) & (df["采样点风化"]==2)].iloc[:,10:])[:,i])[0])
    pv5.append(kstest(pt_10.transform(df[(df["类型"]==1) & (df["采样点风化"]==0)].iloc[:,10:])[:,i], 
                      pt_12.transform(df[(df["类型"]==1) & (df["采样点风化"]==2)].iloc[:,10:])[:,i])[1])
    ks6.append(kstest(pt_11.transform(df[(df["类型"]==1) & (df["采样点风化"]==1)].iloc[:,10:])[:,i], 
                      pt_12.transform(df[(df["类型"]==1) & (df["采样点风化"]==2)].iloc[:,10:])[:,i])[0])
    pv6.append(kstest(pt_11.transform(df[(df["类型"]==1) & (df["采样点风化"]==1)].iloc[:,10:])[:,i], 
                      pt_12.transform(df[(df["类型"]==1) & (df["采样点风化"]==2)].iloc[:,10:])[:,i])[1])
res = pd.DataFrame({"name":name, "ks1":ks1, "pv1":pv1, "ks2":ks2, "pv2":pv2, "ks3":ks3, "pv3":pv3
                    , "ks4":ks4, "pv4":pv4, "ks5":ks5, "pv5":pv5, "ks6":ks6, "pv6":pv6})

x = create_data(df[(df["类型"]==1) & (df["采样点风化"]==0)].iloc[:, [10,12,13,14,15,17,18,19,20,21]])
y1 = df[(df["类型"]==1) & (df["采样点风化"]==0)].iloc[:, 11]
y2 = df[(df["类型"]==1) & (df["采样点风化"]==0)].iloc[:, 16]
y3 = df[(df["类型"]==1) & (df["采样点风化"]==0)].iloc[:, 22]
y4 = df[(df["类型"]==1) & (df["采样点风化"]==0)].iloc[:, 23]

xx = pd.DataFrame()
for i in range(len(df.iloc[:,10:].columns)):
    xx[df.iloc[:,10:].columns[i]] = pt_10.inverse_transform(pt_11.transform(df[(df["类型"]==1) & (df["采样点风化"]==1)].iloc[:,10:]))[:, i]
xx = create_data(xx.iloc[:, [0,2,3,4,5,7,8,9,10,11]])

lm7 = sm.OLS(y1,x.iloc[:, [0,10,13,16,18,27,35,28,30,17,39,40,45,55]]).fit()
lm7.summary()
lm8 = sm.OLS(y2,x.iloc[:, [4,5,7,8,9,10,11,13,14,15,16,17,18,19,20,21,22,23,26,27]]).fit()
lm8.summary()
lm9 = sm.OLS(y3,x.iloc[:, [0,1,2,3,5,6,7,8,10,11,12,13,15,16,17,18,20,21,30]]).fit()
lm9.summary()
lm10 = sm.OLS(y4,x.iloc[:, [5,7,8,12,14,17,18,19,20,26,27,32,39,40,44,50,51,52]]).fit()
lm10.summary()
result_q1_1 = pd.DataFrame({"SiO2":pt_10.inverse_transform(pt_11.transform(df[(df["类型"]==1) & (df["采样点风化"]==1)].iloc[:,10:]))[:, 0],
                            'Na2O':lm7.predict(xx.iloc[:, [0,10,13,16,18,27,35,28,30,17,39,40,45,55]]),
                            'K2O':pt_10.inverse_transform(pt_11.transform(df[(df["类型"]==1) & (df["采样点风化"]==1)].iloc[:,10:]))[:, 2],
                            'CaO':pt_10.inverse_transform(pt_11.transform(df[(df["类型"]==1) & (df["采样点风化"]==1)].iloc[:,10:]))[:, 3],
                            'MgO':pt_10.inverse_transform(pt_11.transform(df[(df["类型"]==1) & (df["采样点风化"]==1)].iloc[:,10:]))[:, 4],
                            'Al2O3':pt_10.inverse_transform(pt_11.transform(df[(df["类型"]==1) & (df["采样点风化"]==1)].iloc[:,10:]))[:, 5],
                            'Fe2O3':lm8.predict(xx.iloc[:, [4,5,7,8,9,10,11,13,14,15,16,17,18,19,20,21,22,23,26,27]]),
                            'CuO':pt_10.inverse_transform(pt_11.transform(df[(df["类型"]==1) & (df["采样点风化"]==1)].iloc[:,10:]))[:, 7],
                            'PbO':pt_10.inverse_transform(pt_11.transform(df[(df["类型"]==1) & (df["采样点风化"]==1)].iloc[:,10:]))[:, 8],
                            'BaO':pt_10.inverse_transform(pt_11.transform(df[(df["类型"]==1) & (df["采样点风化"]==1)].iloc[:,10:]))[:, 9],
                            'P2O5':pt_10.inverse_transform(pt_11.transform(df[(df["类型"]==1) & (df["采样点风化"]==1)].iloc[:,10:]))[:, 10],
                            'SrO':pt_10.inverse_transform(pt_11.transform(df[(df["类型"]==1) & (df["采样点风化"]==1)].iloc[:,10:]))[:, 11],
                            'SnO2':lm9.predict(xx.iloc[:, [0,1,2,3,5,6,7,8,10,11,12,13,15,16,17,18,20,21,30]]),
                            'SO2':lm10.predict(xx.iloc[:, [5,7,8,12,14,17,18,19,20,26,27,32,39,40,44,50,51,52,]])})
result_q1_1[result_q1_1 < 0] = 0
r_1 = pd.concat([df[(df["类型"]==1) & (df["采样点风化"]==1)].iloc[:, 0:10], result_q1_1],
                ignore_index = True,
                axis = 0)
r_1.to_csv("D:/3、竞赛/新建文件夹/q1_1.csv", encoding='utf_8_sig')
q1_r1 = pd.read_csv("D:/3、竞赛/新建文件夹/q1_1.csv")


x = create_data(df[(df["类型"]==1) & (df["采样点风化"]==1)].iloc[:, [10,13,14,15,17,18,19,20,21]])
y5 = df[(df["类型"]==1) & (df["采样点风化"]==1)].iloc[:, 11]
y6 = df[(df["类型"]==1) & (df["采样点风化"]==1)].iloc[:, 12]
y7 = df[(df["类型"]==1) & (df["采样点风化"]==1)].iloc[:, 16]
y8 = df[(df["类型"]==1) & (df["采样点风化"]==1)].iloc[:, 22]
y9 = df[(df["类型"]==1) & (df["采样点风化"]==1)].iloc[:, 23]

xx = pd.DataFrame()
for i in range(len(df.iloc[:,10:].columns)):
    xx[df.iloc[:,10:].columns[i]] = pt_11.inverse_transform(pt_12.transform(df[(df["类型"]==1) & (df["采样点风化"]==2)].iloc[:,10:]))[:, i]
xx = create_data(xx.iloc[:, [0,3,4,5,7,8,9,10,11]])

lm11 = sm.OLS(y5,x.iloc[:, [0,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21]]).fit()
lm11.summary()
lm12 = sm.OLS(y6,x.iloc[:, [0,2,3,4,5,7,8,9,11,12,13,14,15,16,17,19,20,21]]).fit()
lm12.summary()
lm13 = sm.OLS(y7,x.iloc[:, [1,2,7,10,11,13,14,15,16,20,21,26,30,44]]).fit()
lm13.summary()
lm14 = sm.OLS(y8,x.iloc[:, [9,12,14,17,20,21,22,25,30,31,32,39]]).fit()
lm14.summary()
lm15 = sm.OLS(y9,x.iloc[:, [2,18,24,26,28,33,34,35,39,40]]).fit()
lm15.summary()
result_q1_2 = pd.DataFrame({"SiO2":pt_11.inverse_transform(pt_12.transform(df[(df["类型"]==1) & (df["采样点风化"]==2)].iloc[:,10:]))[:, 0],
                            'Na2O':lm11.predict(xx.iloc[:, [0,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21]]),
                            'K2O':lm12.predict(xx.iloc[:, [0,2,3,4,5,7,8,9,11,12,13,14,15,16,17,19,20,21]]),
                            'CaO':pt_11.inverse_transform(pt_12.transform(df[(df["类型"]==1) & (df["采样点风化"]==2)].iloc[:,10:]))[:, 3],
                            'MgO':pt_11.inverse_transform(pt_12.transform(df[(df["类型"]==1) & (df["采样点风化"]==2)].iloc[:,10:]))[:, 4],
                            'Al2O3':pt_11.inverse_transform(pt_12.transform(df[(df["类型"]==1) & (df["采样点风化"]==2)].iloc[:,10:]))[:, 5],
                            'Fe2O3':lm13.predict(xx.iloc[:, [1,2,7,10,11,13,14,15,16,20,21,26,30,44]]),
                            'CuO':pt_11.inverse_transform(pt_12.transform(df[(df["类型"]==1) & (df["采样点风化"]==2)].iloc[:,10:]))[:, 7],
                            'PbO':pt_11.inverse_transform(pt_12.transform(df[(df["类型"]==1) & (df["采样点风化"]==2)].iloc[:,10:]))[:, 8],
                            'BaO':pt_11.inverse_transform(pt_12.transform(df[(df["类型"]==1) & (df["采样点风化"]==2)].iloc[:,10:]))[:, 9],
                            'P2O5':pt_11.inverse_transform(pt_12.transform(df[(df["类型"]==1) & (df["采样点风化"]==2)].iloc[:,10:]))[:, 10],
                            'SrO':pt_11.inverse_transform(pt_12.transform(df[(df["类型"]==1) & (df["采样点风化"]==2)].iloc[:,10:]))[:, 11],
                            'SnO2':lm14.predict(xx.iloc[:, [9,12,14,17,20,21,22,25,30,31,32,39]]),
                            'SO2':lm15.predict(xx.iloc[:, [2,18,24,26,28,33,34,35,39,40]])})
result_q1_2[result_q1_2 < 0] = 0
r_2 = pd.concat([df[(df["类型"]==1) & (df["采样点风化"]==2)].iloc[:, 0:10], result_q1_2],
                ignore_index = True,
                axis = 0)
r_2.to_csv("D:/3、竞赛/新建文件夹/q1_2.csv", encoding='utf_8_sig')
q1_r2 = pd.read_csv("D:/3、竞赛/新建文件夹/q1_2.csv")

xx = create_data(q1_r2.iloc[:, [10,12,13,14,15,17,18,19,20,21]])
result_q1_3 = pd.DataFrame({"SiO2":pt_10.inverse_transform(pt_11.transform(q1_r2.iloc[:, 10:24]))[:, 0],
                            'Na2O':lm7.predict(xx.iloc[:, [0,10,13,16,18,27,35,28,30,17,39,40,45,55]]),
                            'K2O':pt_10.inverse_transform(pt_11.transform(q1_r2.iloc[:, 10:24]))[:, 2],
                            'CaO':pt_10.inverse_transform(pt_11.transform(q1_r2.iloc[:, 10:24]))[:, 3],
                            'MgO':pt_10.inverse_transform(pt_11.transform(q1_r2.iloc[:, 10:24]))[:, 4],
                            'Al2O3':pt_10.inverse_transform(pt_11.transform(q1_r2.iloc[:, 10:24]))[:, 5],
                            'Fe2O3':lm8.predict(xx.iloc[:, [4,5,7,8,9,10,11,13,14,15,16,17,18,19,20,21,22,23,26,27]]),
                            'CuO':pt_10.inverse_transform(pt_11.transform(q1_r2.iloc[:, 10:24]))[:, 7],
                            'PbO':pt_10.inverse_transform(pt_11.transform(q1_r2.iloc[:, 10:24]))[:, 8],
                            'BaO':pt_10.inverse_transform(pt_11.transform(q1_r2.iloc[:, 10:24]))[:, 9],
                            'P2O5':pt_10.inverse_transform(pt_11.transform(q1_r2.iloc[:, 10:24]))[:, 10],
                            'SrO':pt_10.inverse_transform(pt_11.transform(q1_r2.iloc[:, 10:24]))[:, 11],
                            'SnO2':lm9.predict(xx.iloc[:, [0,1,2,3,5,6,7,8,10,11,12,13,15,16,17,18,20,21,30]]),
                            'SO2':lm10.predict(xx.iloc[:, [5,7,8,12,14,17,18,19,20,26,27,32,39,40,44,50,51,52]])})
result_q1_3[result_q1_3 < 0] = 0
r_3 = pd.concat([df[(df["类型"]==1) & (df["采样点风化"]==2)].iloc[:, 0:10], result_q1_3],
                ignore_index = True,
                axis = 0)
r_3.to_csv("D:/3、竞赛/新建文件夹/q1_3.csv", encoding='utf_8_sig')
q1_r1 = pd.read_csv("D:/3、竞赛/新建文件夹/q1_1.csv")


p = plt.subplot(projection = "3d")
p.scatter(df[df["类型"] == 0].iloc[:, 10],
          df[df["类型"] == 0].iloc[:, 12],
          df[df["类型"] == 0].iloc[:, 18],
          label = "高钾")
p.scatter(df[df["类型"] == 1].iloc[:, 10],
          df[df["类型"] == 1].iloc[:, 12],
          df[df["类型"] == 1].iloc[:, 18],
          label = "铅钡")   
p.set_xlabel("SiO2", fontdict={'family': 'Times New Roman', 'size': 15})
p.set_ylabel("K2O", fontdict={'family': 'Times New Roman', 'size': 15})
p.set_zlabel("PbO", fontdict={'family': 'Times New Roman', 'size': 15})
plt.legend()





Q4_data_00 = create_data(df[(df["类型"] == 0) & (df["采样点风化"] == 0)].iloc[:, [10,11,12,17,18,22,23]])
Q4_data_01 = create_data(df[(df["类型"] == 0) & (df["采样点风化"] == 1)].iloc[:, [10,11,12,17,18,22,23]])
Q4_data_10 = create_data(df[(df["类型"] == 1) & (df["采样点风化"] == 0)].iloc[:, [13,14,15,16,19,20,21]])
Q4_data_11 = create_data(df[(df["类型"] == 1) & (df["采样点风化"] == 1)].iloc[:, [13,14,15,16,19,20,21]])
Q4_data_12 = create_data(df[(df["类型"] == 1) & (df["采样点风化"] == 2)].iloc[:, [13,14,15,16,19,20,21]])

Q4_data_00.to_csv("D:/3、竞赛/新建文件夹/q4_data_00.csv", encoding='utf_8_sig')
Q4_data_01.to_csv("D:/3、竞赛/新建文件夹/q4_data_01.csv", encoding='utf_8_sig')
Q4_data_10.to_csv("D:/3、竞赛/新建文件夹/q4_data_10.csv", encoding='utf_8_sig')
Q4_data_11.to_csv("D:/3、竞赛/新建文件夹/q4_data_11.csv", encoding='utf_8_sig')
Q4_data_12.to_csv("D:/3、竞赛/新建文件夹/q4_data_12.csv", encoding='utf_8_sig')


df_q4 =  df.copy()
x1 = df_q4.iloc[:, 10]
x1[df_q4["SiO2"] <= df.iloc[:, 10].describe()[4]] = "SiO2_0"
x1[(df.iloc[:, 10].describe()[4] < df_q4["SiO2"]) & (df_q4["SiO2"] <= df.iloc[:, 10].describe()[5])] = "SiO2_1"
x1[(df.iloc[:, 10].describe()[5] < df_q4["SiO2"]) & (df_q4["SiO2"] <= df.iloc[:, 10].describe()[6])] = "SiO2_2"
x1[(df.iloc[:, 10].describe()[6] < df_q4["SiO2"]) & (df_q4["SiO2"] <= df.iloc[:, 10].describe()[7])] = "SiO2_3"

x2 = df_q4.iloc[:, 11]
x2[df_q4["SiO2"] <= df.iloc[:, 10].describe()[4]] = "SiO2_0"
x2[(df.iloc[:, 10].describe()[4] < df_q4["SiO2"]) & (df_q4["SiO2"] <= df.iloc[:, 10].describe()[5])] = "SiO2_1"
x2[(df.iloc[:, 10].describe()[5] < df_q4["SiO2"]) & (df_q4["SiO2"] <= df.iloc[:, 10].describe()[6])] = "SiO2_2"
x2[(df.iloc[:, 10].describe()[6] < df_q4["SiO2"]) & (df_q4["SiO2"] <= df.iloc[:, 10].describe()[7])] = "SiO2_3"


df_q4 =  df.copy()
for i in df.iloc[:, 10:].columns:
    data = df_q4[i].copy()
    data = pd.cut(data, 4, labels = [i+"_0",i+"_1",i+"_2",i+"_3"])
    df_q4[i] = data


""" ==================== 七、第二问 ==================== """

""" =============== 7.1.2 亚类划分 =============== """
""" ========== K-means ========== """
def Kmeans(data, n_clusters):
    from sklearn.cluster import KMeans
    model = KMeans(n_clusters, random_state = 1).fit(data)
    return model, model.labels_
    
""" ========== Spectral clustering ========== """
def SC(data, n_clusters):
    from sklearn.cluster import SpectralClustering
    model = SpectralClustering(n_clusters,
                               assign_labels='discretize',
                               random_state=1).fit(data)
    return model, model.labels_

""" ========== BIRCH ========== """
def BIRCH(data, n_clusters):
    from sklearn.cluster import Birch
    model = Birch(n_clusters = n_clusters).fit(data)
    model.predict(data)
    return model, model.labels_

""" ========== Agglomerative Clustering ========== """
def AC(data, n_clusters):
    from sklearn.cluster import AgglomerativeClustering
    model = AgglomerativeClustering(n_clusters).fit(data)
    return model, model.labels_
    
""" ========== Gaussian Mixture ========== """
def GM(data, n_components):
    from sklearn.mixture import GaussianMixture
    model = GaussianMixture(n_components, random_state=0).fit(data)
    return model, GaussianMixture(n_components, random_state=0).fit_predict(data)

""" ========== Affinity Propagation ========== """
def AP(data):
    from sklearn.cluster import AffinityPropagation
    model = AffinityPropagation(random_state=5).fit(data)
    return model, model.labels_

""" ========== Mean shift ========== """
def MS(data):
    from sklearn.cluster import MeanShift, estimate_bandwidth
    bandwidth = estimate_bandwidth(data, quantile=0.2, n_samples=500)
    model = MeanShift(bandwidth=bandwidth, bin_seeding=True).fit(data)
    return model, model.labels_

""" ========== DBSCAN ========== """
def DBSCAN(data):
    from sklearn.cluster import DBSCAN
    model = DBSCAN(eps=3, min_samples=2).fit(data)
    return model, model.labels_

""" ========== OPTICS ========== """
def OPTICS(data):
    from sklearn.cluster import OPTICS
    model = OPTICS(min_samples=3).fit(data)
    return model, model.labels_

def eva_score(data, labels):
    from sklearn.metrics import silhouette_score, calinski_harabasz_score, davies_bouldin_score
    # 轮廓系数
    silhouette = silhouette_score(data, labels, metric='euclidean')
    # Calinski-Harabasz 指数
    calinski_harabasz = calinski_harabasz_score(data, labels)
    # davies-bouldin 指数
    davies_bouldin = davies_bouldin_score(data, labels)
    return silhouette, calinski_harabasz, davies_bouldin


# 读取数据
def evm_topsis(data):
    import copy
    # 数据标准化
    data = np.array(data)
    [m, n] = data.shape
    data2 = copy.deepcopy(data)
    ymin = 0.002
    ymax = 1
    for j in range(0, n):
        d_max = max(data[:, j])
        d_min = min(data[:, j])
        data2[:, j] = (ymax - ymin) * (data[:, j] - d_min) / (d_max - d_min) + ymin
    
    # 计算信息熵
    p = copy.deepcopy(data2)
    for j in range(0, n):
        p[:, j] = data2[:, j] / sum(data2[:, j])
    E = copy.deepcopy(data2[0, :])
    for j in range(0, n):
        E[j] = -1/np.log(m)*sum(p[:,j]*np.log(p[:,j]))
 
    # 计算加权重后的数据
    w = (1 - E) / sum(1 - E)
    R = data2 * w

    # 计算最大最小值距离
    r_max = np.max(R, axis=0)  # 每个指标的最大值
    r_min = np.min(R, axis=0)  # 每个指标的最小值
    d_z = np.sqrt(np.sum(np.square((R - np.tile(r_max, (m, 1)))), axis=1))  # d+向量
    d_f = np.sqrt(np.sum(np.square((R - np.tile(r_min, (m, 1)))), axis=1))  # d-向量

    # 计算得分
    s = d_f / (d_z + d_f)
    Score = 100 * s / max(s)
    Scores = pd.DataFrame(Score)
    max_index = Scores[Scores.iloc[:, 0] == max(Scores.iloc[:, 0])].index[0]
    for o in range(0, len(Score)):
        print(f"第{o + 1}个评价对象的得分：{Score[o]}")
    return max_index

# 对于人为设定簇的算法，调整簇使得性能最大化
def search_n(data):
    A = []
    B = []
    C = []
    D = []
    E = []
    F = []
    G = []
    H = []
    I = []
    J = []
    K = []
    L = []
    M = []
    N = []
    O = []
    for i in range(2, 6):
        km, l1 = Kmeans(data, i)
        s1= eva_score(data, l1)
        A.append(s1[0])
        B.append(s1[1])
        C.append(s1[2] * -1)
        sc, l2 = SC(data, i)
        s2 = eva_score(data, l2)
        D.append(s2[0])
        E.append(s2[1])
        F.append(s2[2] * -1)
        ac, l3 = AC(data, i)
        s3 = eva_score(data, l3)
        G.append(s3[0])
        H.append(s3[1])
        I.append(s3[2] * -1)
        bi, l4 = BIRCH(np.array(data).tolist(), i)
        s4 = eva_score(data, l4)
        J.append(s4[0])
        K.append(s4[1])
        L.append(s4[2] * -1)
        gm, l5 = GM(np.array(data).tolist(), i)
        s5 = eva_score(data, l5)
        M.append(s5[0])
        N.append(s5[1])
        O.append(s5[2] * -1)
    df_km = pd.DataFrame({"silhouette":A, "calinski_harabasz":B, "davies_bouldin":C})
    df_sc = pd.DataFrame({"silhouette":D, "calinski_harabasz":E, "davies_bouldin":F})
    df_ac = pd.DataFrame({"silhouette":G, "calinski_harabasz":H, "davies_bouldin":I})
    df_bi = pd.DataFrame({"silhouette":J, "calinski_harabasz":K, "davies_bouldin":L})
    df_gm = pd.DataFrame({"silhouette":M, "calinski_harabasz":N, "davies_bouldin":O})
    i_km = evm_topsis(df_km)
    i_sc = evm_topsis(df_sc)
    i_ac = evm_topsis(df_ac)
    i_bi = evm_topsis(df_bi)
    i_gm = evm_topsis(df_gm)
    
    ap, l6 = AP(data)
    ms, l7 = MS(data)
    db, l8 = DBSCAN(data)
    op, l9 = OPTICS(data)
    i_ap = len(set(l6))
    i_ms = len(set(l7))
    i_db = len(set(l8))
    i_op = len(set(l9))
    s6= eva_score(data, l6)
    s7= eva_score(data, l7)
    s8= eva_score(data, l8)
    s9= eva_score(data, l9)

    d = pd.DataFrame({"km"+str(i_km):df_km.iloc[i_km,:],
                      "sc"+str(i_sc):df_sc.iloc[i_sc,:],
                      "ac"+str(i_ac):df_ac.iloc[i_ac,:],
                      "bi"+str(i_bi):df_bi.iloc[i_bi,:],
                      "gm"+str(i_gm):df_gm.iloc[i_gm,:],
                      "ap"+str(i_ap):[s6[0], s6[1], s6[2]],
                      "ms"+str(i_ms):[s7[0], s7[1], s7[2]],
                      "db"+str(i_db):[s8[0], s8[1], s8[2]],
                      "op"+str(i_op):[s9[0], s9[1], s9[2]]
                      })
    d_e = pd.DataFrame({"silhouette": d.iloc[0,:],
                       "calinski_harabasz":d.iloc[1,:],
                       "davies_bouldin":d.iloc[2,:]
                       })
    i_best = evm_topsis(d_e)
    return d_e.index[i_best], d_e.iloc[i_best, :]

df = pd.read_csv("D:/3、竞赛/新建文件夹/sheet2_nw.csv")
A = df[df["类型"] == 0].iloc[:, 10:]
B = df[df["类型"] == 1].iloc[:, 10:]

name = []
ks = []
pv = []
from scipy.stats import kruskal
for i in range(len(A.columns)):
    x1 = A[A.columns[i]]
    x2 = B[A.columns[i]]
    name.append(A.columns[i])
    ks.append(kruskal(x1, x2)[0])
    pv.append(kruskal(x1, x2)[1])
ksres = pd.DataFrame({"name" : name, "ks" : ks, "pv":pv})
p = pv.copy()
p.sort()
index = []
for i in range(len(A.columns)):
    index.append(pv.index(p[i]))

x = {name[index[0]] : A[name[index[0]]],
     name[index[1]] : A[name[index[1]]], 
     name[index[2]] : A[name[index[2]]]}
n = []
best_method = []
s1 = []
s2 = []
s3 = []
for i in range(3,11):
    n.append(len(x))
    bm, s = search_n(pd.DataFrame(x))
    best_method.append(bm)
    s1.append(s[0])
    s2.append(s[1])
    s3.append(s[2])
    x[name[index[i]]] = A[name[index[i]]]
d_e = pd.DataFrame({"silhouette": s1,
                    "calinski_harabasz":s2,
                    "davies_bouldin":s3})
i_best = evm_topsis(d_e)


x = {name[index[0]] : B[name[index[0]]],
     name[index[1]] : B[name[index[1]]], 
     name[index[2]] : B[name[index[2]]]}
n = []
best_method = []
s1 = []
s2 = []
s3 = []
for i in range(3,11):
    n.append(len(x))
    bm, s = search_n(pd.DataFrame(x))
    best_method.append(bm)
    s1.append(s[0])
    s2.append(s[1])
    s3.append(s[2])
    x[name[index[i]]] = B[name[index[i]]]
d_e = pd.DataFrame({"silhouette": s1,
                    "calinski_harabasz":s2,
                    "davies_bouldin":s3})
i_best = evm_topsis(d_e)

""" =============== 7.1.2 敏感性检验 =============== """
from sklearn.metrics import cohen_kappa_score
x = pd.DataFrame({name[index[0]] : A[name[index[0]]],
                  name[index[1]] : A[name[index[1]]], 
                  name[index[2]] : A[name[index[2]]],
                  name[index[3]] : A[name[index[3]]],
                  name[index[4]] : A[name[index[4]]], 
                  name[index[5]] : A[name[index[5]]],
                  name[index[6]] : A[name[index[6]]],
                  name[index[7]] : A[name[index[7]]], 
                  name[index[8]] : A[name[index[8]]],
                  name[index[9]] : A[name[index[9]]]})
clu_0, clu_0_labels = OPTICS(x)

na = []
change = []
kappa = []
for i in range(len(x.columns)):
    for j in np.arange(0.1, 1.1, 0.1) / 10:
        na.append(x.columns[i])
        change.append(j)
        xx = x.copy()
        xx[x.columns[i]] = xx[x.columns[i]] * (1 + j)
        new_labels = clu_0.fit_predict(xx)
        kappa.append(cohen_kappa_score(clu_0_labels, new_labels))
    for j in -1 *  np.arange(0.1, 1.1, 0.1) / 10:
        na.append(x.columns[i])
        change.append(j)
        xx = x.copy()
        xx[x.columns[i]] = xx[x.columns[i]] * (1 + j)
        new_labels = clu_0.fit_predict(xx)
        kappa.append(cohen_kappa_score(clu_0_labels, new_labels))
Q3_res_0 = pd.DataFrame({"变量":na,
                         "改变":change,
                         "kappa":kappa})
Q3_res_0[Q3_res_0["kappa"]!=1]

x = pd.DataFrame({name[index[0]] : B[name[index[0]]],
                  name[index[1]] : B[name[index[1]]], 
                  name[index[2]] : B[name[index[2]]],
                  name[index[3]] : B[name[index[3]]],
                  name[index[4]] : B[name[index[4]]],
                  name[index[5]] : B[name[index[5]]]})
clu_1, clu_1_labels = AP(x)

na = []
change = []
kappa = []
for i in range(len(x.columns)):
    for j in np.arange(0.1, 1.1, 0.1) / 10:
        na.append(x.columns[i])
        change.append(j)
        xx = x.copy()
        xx[x.columns[i]] = xx[x.columns[i]] * (1 + j)
        new_labels = clu_1.fit_predict(xx)
        kappa.append(cohen_kappa_score(clu_1_labels, new_labels))
    for j in -1 *  np.arange(0.1, 1.1, 0.1) / 10:
        na.append(x.columns[i])
        change.append(j)
        xx = x.copy()
        xx[x.columns[i]] = xx[x.columns[i]] * (1 + j)
        new_labels = clu_1.fit_predict(xx)
        kappa.append(cohen_kappa_score(clu_1_labels, new_labels))
Q3_res_1 = pd.DataFrame({"变量":na,
                         "改变":change,
                         "kappa":kappa})
Q3_res_1[Q3_res_1["kappa"]!=1]


""" =============== 8.1.2 敏感性检验 =============== """
from sklearn.metrics import cohen_kappa_score
df3 = pd.read_csv("D:/3、竞赛/新建文件夹/sheet3.csv")
x = pd.DataFrame({name[index[0]] : A[name[index[0]]],
                  name[index[1]] : A[name[index[1]]], 
                  name[index[2]] : A[name[index[2]]],
                  name[index[3]] : A[name[index[3]]],
                  name[index[4]] : A[name[index[4]]], 
                  name[index[5]] : A[name[index[5]]],
                  name[index[6]] : A[name[index[6]]],
                  name[index[7]] : A[name[index[7]]], 
                  name[index[8]] : A[name[index[8]]],
                  name[index[9]] : A[name[index[9]]]})
clu_0, clu_0_labels = OPTICS(x)
true_labels = clu_0.fit_predict(df3.iloc[:, [10,4,11,5,13,2,7,9,6,12]])


na = []
change = []
kappa = []
for i in range(len(x.columns)):
    for j in np.arange(0.1, 2.1, 0.1) / 10:
        na.append(x.columns[i])
        change.append(j)
        df3_0 = df3.iloc[:, [10,4,11,5,13,2,7,9,6,12]]
        a = df3_0[x.columns[i]].values * (1 + j)
        df3_0[x.columns[i]] = a
        new_labels = clu_0.fit_predict(df3_0)
        kappa.append(cohen_kappa_score(true_labels, new_labels))
    for j in -1*np.arange(0.1, 2.1, 0.1) / 10:
        na.append(x.columns[i])
        change.append(j)
        df3_0 = df3.iloc[:, [10,4,11,5,13,2,7,9,6,12]]
        a = df3_0[x.columns[i]].values * (1 + j)
        df3_0[x.columns[i]] = a
        new_labels = clu_0.fit_predict(df3_0)
        kappa.append(cohen_kappa_score(true_labels, new_labels))
Q3_res_0 = pd.DataFrame({"变量":na,
                         "改变":change,
                         "kappa":kappa})
Q3_res_0[Q3_res_0["kappa"]!=1]

x = pd.DataFrame({name[index[0]] : B[name[index[0]]],
                  name[index[1]] : B[name[index[1]]], 
                  name[index[2]] : B[name[index[2]]],
                  name[index[3]] : B[name[index[3]]],
                  name[index[4]] : B[name[index[4]]],
                  name[index[5]] : B[name[index[5]]]})
clu_1, clu_1_labels = AP(x)
true_labels = clu_1.fit_predict(df3.iloc[:, [10,4,11,5,13,2]])

na = []
change = []
kappa = []
for i in range(len(x.columns)):
    for j in np.arange(0.1, 1.1, 0.1) / 10:
        na.append(x.columns[i])
        change.append(j)
        df3_1 = df3.iloc[:, [10,4,11,5,13,2]]
        a = df3_1[x.columns[i]].values * (1 + j)
        df3_1[x.columns[i]] = a
        new_labels = clu_0.fit_predict(df3_1)
        kappa.append(cohen_kappa_score(true_labels, new_labels))
    for j in -1*np.arange(0.1, 1.1, 0.1) / 10:
        na.append(x.columns[i])
        change.append(j)
        df3_1 = df3.iloc[:, [10,4,11,5,13,2]]
        a = df3_1[x.columns[i]].values * (1 + j)
        df3_1[x.columns[i]] = a
        new_labels = clu_1.fit_predict(df3_1)
        kappa.append(cohen_kappa_score(true_labels, new_labels))
Q3_res_0 = pd.DataFrame({"变量":na,
                         "改变":change,
                         "kappa":kappa})
Q3_res_0[Q3_res_0["kappa"]!=1]

Q3_res_0.to_csv("D:/3、竞赛/新建文件夹/sheet3_res.csv")


""" ==================== 九、第四问 ==================== """
""" =============== 9.1.1 灰色关联分析 =============== """
df = pd.read_csv("D:/3、竞赛/新建文件夹/sheet2.csv")
# 标准化函数
def Standard(df_values, df_columns):
    from sklearn import preprocessing
    scaler = preprocessing.StandardScaler()
    data = scaler.fit_transform(df_values)
    return pd.DataFrame(data, columns = df_columns)

# 求第一列的影响因素和其它所有列影响因素的灰色关联值
def GRA_ONE(data, m = 0): # m为参考列
    data = Standard(data.values, data.columns)
    std = data.iloc[:, m]
    ce = data.copy()
    n = ce.shape[0]
    m = ce.shape[1]
    grap = np.zeros([n,m])
    for i in range(m):
        for j in range(n):
            grap[j,i] = abs(ce.iloc[j,i] - std[j])
    mmax = np.amax(grap)
    mmin = np.amin(grap)
    ρ = 0.5
    grap = pd.DataFrame(grap).applymap(lambda x:(mmin+ρ*mmax)/(x+ρ*mmax))
    RT = grap.mean(axis=0)
    return pd.Series(RT)

# 调用GRA_ONE，求得所有因素之间的灰色关联值
def GRA(data):
    list_columns = np.arange(data.shape[1])
    df_local = pd.DataFrame(columns = list_columns)
    for i in np.arange(data.shape[1]):
        df_local.iloc[:, i] = GRA_ONE(data, m = i)
    return df_local

def ShowGRAHeatMap(data, stri = ""):
    colormap = plt.cm.OrRd
    plt.figure()
    plt.title(stri + '灰色关联度分析',size=18)
    sns.heatmap(data.astype(float), linewidths = 0.1, vmax = 1.0, 
                square = True, cmap = colormap,
                linecolor = 'white', annot = True)
    plt.show()

data1 = df[(df["类型"]==0) & (df["采样点风化"]==0)].iloc[:, 10:]
data2 = df[(df["类型"]==0) & (df["采样点风化"]==1)].iloc[:, 10:]
data2 = df[(df["类型"]==0) & (df["采样点风化"]==1)].iloc[:, [10,12,13,14,15,16,17,20]]
data3 = df[(df["类型"]==1) & (df["采样点风化"]==0)].iloc[:, 10:]
data4 = df[(df["类型"]==1) & (df["采样点风化"]==1)].iloc[:, 10:]
data5 = df[(df["类型"]==1) & (df["采样点风化"]==2)].iloc[:, 10:]
data5 = df[(df["类型"]==1) & (df["采样点风化"]==2)].iloc[:, [10,12,13,14,15,17,18,19,20,21,23]]
data1_gra = GRA(data1)
data1_gra.columns = data1.columns
data1_gra.index = data1.columns
data2_gra = GRA(data2)
data2_gra.columns = data2.columns
data2_gra.index = data2.columns
data3_gra = GRA(data3)
data3_gra.columns = data3.columns
data3_gra.index = data3.columns
data4_gra = GRA(data4)
data4_gra.columns = data4.columns
data4_gra.index = data4.columns
data5_gra = GRA(data5)
data5_gra.columns = data5.columns
data5_gra.index = data5.columns
ShowGRAHeatMap(data1_gra, "无风化高钾玻璃的")
ShowGRAHeatMap(data2_gra, "风化高钾玻璃的")
ShowGRAHeatMap(data3_gra, "无风化铅钡玻璃的")
ShowGRAHeatMap(data4_gra, "风化铅钡玻璃的")
ShowGRAHeatMap(data5_gra, "严重风化铅钡玻璃的")

""" =============== 9.1.2 Wilcoxon秩和检验 =============== """
from scipy.stats import ranksums
fried = data1_gra.copy()
pv = data1_gra.copy()
for i in range(0, len(data1.columns)):
    for j in range(0, len(data1.columns)):
        a1 = []
        a2 = []
        a1.append(data1_gra.iloc[i,j])
        a1.append(data2_gra.iloc[i,j])
        a2.append(data3_gra.iloc[i,j])
        a2.append(data4_gra.iloc[i,j])
        a2.append(data5_gra.iloc[i,j])
        fried.iloc[i,j] = ranksums(a1, a2)[0]
        pv.iloc[i,j] = ranksums(a1, a2)[1]

plt.figure()
plt.title("Wilcoxon秩和检验的统计量",size=18)
sns.heatmap(fried.astype(float),linewidths=0.1,vmax=1.0,square=True,\
           cmap= plt.cm.RdYlGn,linecolor='white',annot=True)
plt.show()

plt.figure()
plt.title("Wilcoxon秩和检验的P-value",size=18)
sns.heatmap(pv.astype(float),linewidths=0.1,vmax=1.0,square=True,\
           cmap= plt.cm.RdYlGn,linecolor='white',annot=True)
plt.show()


""" =============== 9.1.3 多项式回归 =============== """
import statsmodels.api as sm
from sklearn import preprocessing
res_Q4 = {}
for i in range(0, len(data1.columns)):
    for j in range(i, len(data1.columns)):
        if pv.iloc[i,j] < 0.1:
            name = data1.columns[i] + " and " + data1.columns[j]
            lm_res = {}
            for k in [[0,0],[0,1],[1,0],[1,1],[1,2]]:
                data = df[(df["类型"]==k[0]) & (df["采样点风化"]==k[1])].iloc[:,10:]
                pt = preprocessing.PowerTransformer().fit(data)
                data = pt.transform(data)
                scaler = preprocessing.StandardScaler().fit(data)
                data = scaler.transform(data)
                y = data[:, i]
                x = data[:, j]
                X = pd.DataFrame({"x":x, "x^2":x*x})
                lm = sm.OLS(y, X).fit()
                lm_res[str(k[0])+str(k[1])] = {"R^2":lm.rsquared, 
                                               "f-p-value":lm.f_pvalue, 
                                               "t-p-value":lm.pvalues,
                                               "params":lm.params}
            res_Q4[name] = lm_res
print(res_Q4)








