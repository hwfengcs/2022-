# %%
import pandas as pd
import numpy as np
from sklearn.metrics import recall_score,accuracy_score,confusion_matrix, f1_score, precision_score, auc,roc_auc_score,roc_curve, precision_recall_curve
from sklearn.model_selection import train_test_split
from sklearn.ensemble import (RandomForestClassifier,GradientBoostingClassifier,BaggingClassifier,AdaBoostClassifier)
from sklearn.metrics import (recall_score,accuracy_score,confusion_matrix, f1_score, precision_score, 
                             auc,roc_auc_score,roc_curve, precision_recall_curve,classification_report)
from sklearn.model_selection import GridSearchCV,train_test_split
from sklearn.linear_model import LogisticRegression
from catboost import CatBoostClassifier
from catboost import Pool
from catboost import cv
from sklearn.metrics import accuracy_score
from xgboost import XGBClassifier 
import seaborn as sns
from imblearn.over_sampling import RandomOverSampler, SMOTE, BorderlineSMOTE, SVMSMOTE, ADASYN
from imblearn.combine import SMOTEENN,SMOTETomek
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import KFold, cross_val_score
from sklearn.svm import SVC
from sklearn.feature_selection import SelectKBest, f_classif
import matplotlib.pyplot as plt
from sklearn import metrics,tree,svm
from sklearn.linear_model import LinearRegression
from sklearn.naive_bayes import GaussianNB
from sklearn.neighbors import KNeighborsClassifier
import lightgbm as lgb
import scorecardpy as sc
from mpl_toolkits.axes_grid1.inset_locator import mark_inset
from scipy.stats import kruskal,kstest
from sklearn.preprocessing import StandardScaler
from statsmodels.discrete.discrete_model import Logit, Probit, MNLogit
import statsmodels.tools

plt.rcParams['font.sans-serif']=['SimHei'] #显示中文标签
plt.rcParams['axes.unicode_minus']=False

# %%
#问题一------------------------
q1 = pd.read_csv("sheet2_fin.csv")
q1_0 = q1[(q1.iloc[:,-1] == 0)]
q1_1 = q1[(q1.iloc[:,-1] == 1)]

display(q1)
display(q1_0)
display(q1_1)

# %%
q1_0.iloc[:,9:23].describe().to_csv("q1-0.csv")
q1_1.iloc[:,9:23].describe().to_csv("q1-1.csv")

# %%
#正态性检验
sum = []
for i in range(9,23):
    y = kstest(q1.iloc[:,i],cdf = "norm")
    sum.append(y)
sum

# %%
#K-W非参数检验
sum = []
for i in range(9,23):
    y = kruskal(q1_0[(q1_0.iloc[:,8] == 0)].iloc[:,i], q1_0[(q1_0.iloc[:,8] == 1)].iloc[:,i])
    sum.append(y)
sum

# %%
sum = []
for i in range(9,23):
    y = kruskal(q1_1[(q1_1.iloc[:,8] == 0)].iloc[:,i], q1_1[(q1_1.iloc[:,8] == 1)].iloc[:,i],q1_1[(q1_1.iloc[:,8] == 2)].iloc[:,i])
    sum.append(y)
sum

# %%


# %%
#核密度图
plt.figure(figsize=(36,9),dpi = 600)
for i in range(14):
    ax = plt.subplot(2,7,i+1)
    color1 = ["#B897EC","#FB93D9","#FF99B4","#FFB08C","#FFD36F","#659140","#6796F1","#0094E4","#008EC4","#008394","#00745A","#8164B4","#F48974","#4D8076"]
    color2 = ["#FF99B4","#5394E2","#6E6C96","#B87C9A","#62A978","#007966","#00D4EF","#00CED8","#43DDA6","#70D38D","#0087BF","#FF9A77","#898E24","#4D7BA7"]
    ax = sns.kdeplot(q1_0[(q1_0.iloc[:,8] == 0)].iloc[:,i+9], color = color1[i], label = '无风化{}含量'.format(q1.columns[i+9]), shade = False)
    ax = sns.kdeplot(q1_0[(q1_0.iloc[:,8] == 1)].iloc[:,i+9], color = color2[i], label = '风化{}含量'.format(q1.columns[i+9]), shade = False)
    plt.legend()

# %%
plt.figure(figsize=(36,9),dpi = 600)
for i in range(14):
    ax = plt.subplot(2,7,i+1)
    color1 = ["#B897EC","#FB93D9","#FF99B4","#FFB08C","#FFD36F","#659140","#6796F1","#0094E4","#008EC4","#008394","#00745A","#8164B4","#F48974","#4D8076"]
    color2 = ["#FF99B4","#5394E2","#6E6C96","#B87C9A","#62A978","#007966","#00D4EF","#00CED8","#43DDA6","#70D38D","#0087BF","#FF9A77","#898E24","#4D7BA7"]
    color3 = ["#2F4858","#00CFE1","#FFC76F","#617BB5","#62A978","#009474","#509BED","#90F09B","#E067A4","#077F8A","#6A72C0","#E067A4","#25834E","#3BD6AB"]
    ax = sns.kdeplot(q1_1[(q1_1.iloc[:,8] == 0)].iloc[:,i+9], color = color1[i], label = '无风化{}含量'.format(q1.columns[i+9]), shade = False)
    ax = sns.kdeplot(q1_1[(q1_1.iloc[:,8] == 1)].iloc[:,i+9], color = color2[i], label = '风化{}含量'.format(q1.columns[i+9]), shade = False)
    ax = sns.kdeplot(q1_1[(q1_1.iloc[:,8] == 2)].iloc[:,i+9], color = color3[i], label = '严重风化{}含量'.format(q1.columns[i+9]), shade = False)
    plt.legend()

# %%
dataplot1 = pd.DataFrame(data = q1[(q1.iloc[:,8] == 0)].iloc[:,9])
dataplot2 = pd.DataFrame(data = q1[(q1.iloc[:,8] == 1)].iloc[:,9])
dataplot1.reset_index(drop = True,inplace =True)
dataplot2.reset_index(drop = True,inplace =True)
dataplot = pd.concat([dataplot1,dataplot2],axis=1)
dataplot*0.9


# %%
#LR------------------------------
############################################
# LR_tuned_params = {'C': 1, 
#                    'penalty': 'l2', 
#                    'solver': 'newton-cg'
#                   }

LR = LogisticRegression(random_state = 88)

#LR------------------------------
############################################



#decision_tree--------------------
############################################
# DT_tuned_params = {'criterion':'gini',
#                     'splitter':'random',
#                     'min_samples_leaf':26,
#                     'min_samples_split':70,
#                     'max_features':20
# }
DT = tree.DecisionTreeClassifier(random_state = 88)

#decision_tree--------------------
############################################


#SVM------------------------------
############################################
# SVM_tuned_params = {'C': 1000,
#                     'gamma': 0.0001, 
#                     'kernel': 'rbf',
#                      'probability': True
#                     }
SVM = SVC(random_state=88,probability=True)

#SVM------------------------------
############################################



#贝叶斯分类------------------------
#############################################0
gnb = GaussianNB()

#贝叶斯分类------------------------
#############################################


#AdaBoost--------------
#############################################
# adaboost_tuned_params = {'n_estimators': 250,
#                   'learning_rate': 0.05, 
#                   "algorithm": "SAMME.R"
#                   }

adaboost = AdaBoostClassifier(random_state=88)

#AdaBoost--------------
#############################################

#GBDT----------------------------
############################################
# GBDT_tuned_params = {"max_features":1.0,
#                   "max_depth": None,
#                   "min_samples_leaf" : 2,
#                   "max_depth" : 5,
#                   'learning_rate': 0.08, 
#                   'n_estimators': 100,
#                   "subsample": 0.85
#                   }

GBDT = GradientBoostingClassifier(random_state=88)

#GBDT----------------------------
###############################################



#xgBoost-----------------------------
#####################################################
# xgboost_tuned_params = {"n_estimators" : 250,
#                     "learning_rate": 0.1,
#                     'max_depth':7,
#                     'min_child_weight':5
                  
# }
xgboost = XGBClassifier(random_state=88)

#xgBoost-----------------------------
#####################################################

#CatBoost-------------------------
########################################
# CatBoost_tuned_params = {'depth': 4,
#                         'learning_rate' : 0.1,    
# }

CatBoost = CatBoostClassifier(random_seed=88)

#CatBoost-------------------------
########################################

#LightGBM-------------------------
########################################
# LightGBM_tuned_params = {'n_estimators': 250,

#                     'learning_rate' :0.1
#                   }

LightGBM = lgb.LGBMClassifier(random_seed=88)
#LightGBM-------------------------
########################################




#RF------------------------------
############################################
# RF_tuned_params = {'max_depth': None,
#                    'max_features': 'sqrt',
#                    'min_samples_leaf': 1,
#                    'n_jobs': -1,
#                    'n_estimators': 160,
#                   }

RF = RandomForestClassifier(random_state=88)
#RF------------------------------
############################################

# %%
q1_00 = q1_0[(q1_0.iloc[:,8] == 0)]
q1_00["label"] = 0
q1_01 = q1_0[(q1_0.iloc[:,8] == 1)]
q1_01["label"] = 1
q1_02 = q1_0[(q1_0.iloc[:,8] == 2)]
q1_02["label"] = 2
q1_10 = q1_1[(q1_1.iloc[:,8] == 0)]
q1_10["label"] = 3
q1_11 = q1_1[(q1_1.iloc[:,8] == 1)]
q1_11["label"] = 4
q1_12 = q1_1[(q1_1.iloc[:,8] == 2)]
q1_12["label"] = 5
q1_ml = pd.concat([q1_00,q1_01,q1_02,q1_10,q1_11,q1_12],axis = 0)
q1_ml

# %%
#分成6类
#设置训练集和测试集
X = q1_ml.iloc[:,9:23]
y = q1_ml.iloc[:,-1]

#指定random_state = 88
X_train, X_test, y_train, y_test = train_test_split(X,y,test_size = 0.20, random_state = 88)

# %%
#创建展示结果的展示数据框
test_set_result = pd.DataFrame()
#f1,prec,recall,acc,ROC_AUC,conf = ([],[],[],[],[],[])
f1,prec,recall,acc,conf = ([],[],[],[],[])

#评估不同分类模型的结果
for model_name in ['LR','DT','SVM','gnb','adaboost','GBDT','xgboost','CatBoost','LightGBM','RF']:
    model = eval(model_name)

    model.fit(X_train, y_train.ravel())

    pred_test = model.predict(X_test)
    pred_test_probs = model.predict_proba(X_test)
    #fpr, tpr, thresholds = roc_curve(y_test,pred_test)

    f1.append(f1_score(y_test,pred_test,average='macro'))
    prec.append(precision_score(y_test,pred_test,average='macro'))
    recall.append(recall_score(y_test,pred_test,average='macro'))
    acc.append(accuracy_score(y_test,pred_test))
    #ROC_AUC.append(roc_auc_score(y_test, pred_test_probs[:,1]))       
    conf.append(confusion_matrix(y_test,pred_test))
    
test_set_scores = zip(f1,prec,recall,acc,conf)   

test_set_result = pd.DataFrame(test_set_scores, 
                               columns=['F1','precision','recall',
                                        'accuracy','confusion_matrix'], 
                               index = ['LR','DT','SVM','gnb','adaboost','GBDT','xgboost','CatBoost','LightGBM','RF'])
test_set_result.round(4)

# %%
# 特征重要性
# dt_imp = DT.feature_importances_ / sum(DT.feature_importances_)
ada_imp = adaboost.feature_importances_ / np.sum(adaboost.feature_importances_)
gbdt_imp = GBDT.feature_importances_ / np.sum(GBDT.feature_importances_)
xgb_imp = xgboost.feature_importances_ / np.sum(xgboost.feature_importances_)
cat_imp = CatBoost.feature_importances_ / np.sum(CatBoost.feature_importances_)
lgbm_imp = LightGBM.feature_importances_ / np.sum(LightGBM.feature_importances_)
rf_imp =RF.feature_importances_ / np.sum(RF.feature_importances_)


labels = q1_ml.columns[9:23]
x = np.arange(0.5,28.5,2)
w = 0.3
fig, ax = plt.subplots(1, 1, figsize=(24,9),dpi = 600)
r1 = ax.bar(x - 2.5*w, rf_imp, w, label = "RandomForest")
r2 = ax.bar(x - 1.5*w, ada_imp, w, label = "AdaBoost")
r3 = ax.bar(x - 0.5*w, gbdt_imp, w, label = "GBDT")
r4 = ax.bar(x + 0.5*w, xgb_imp, w, label = "XGBoost")
r5 = ax.bar(x + 1.5*w, cat_imp, w, label = "CatBoost")
r6 = ax.bar(x + 2.5*w, lgbm_imp, w, label = "LightGBM")

ax.set_ylabel("Importance", fontdict={'family': 'Times New Roman', 'size': 15})
ax.set_xlabel("Features", fontdict={'family': 'Times New Roman', 'size': 15})
ax.set_xticks(x)
ax.set_xticklabels(labels)
ax.set_title("Importance by Different Models", 
             fontdict={'family': 'Times New Roman', 'size': 15})
ax.legend()

# %%
#高钾玻璃的风化程度分类
#设置训练集和测试集
X = q1_0.iloc[:,9:23]
y = q1_0.iloc[:,8]

#指定random_state = 88
X_train, X_test, y_train, y_test = train_test_split(X,y,test_size = 0.20, random_state = 88)

# %%
#创建展示结果的展示数据框
test_set_result = pd.DataFrame()
#f1,prec,recall,acc,ROC_AUC,conf = ([],[],[],[],[],[])
f1,prec,recall,acc,conf = ([],[],[],[],[])

#评估不同分类模型的结果
for model_name in ['LR','DT','SVM','gnb','adaboost','GBDT','xgboost','CatBoost','LightGBM','RF']:
    model = eval(model_name)

    model.fit(X_train, y_train.ravel())

    pred_test = model.predict(X_test)
    pred_test_probs = model.predict_proba(X_test)
    #fpr, tpr, thresholds = roc_curve(y_test,pred_test)

    f1.append(f1_score(y_test,pred_test,average='macro'))
    prec.append(precision_score(y_test,pred_test,average='macro'))
    recall.append(recall_score(y_test,pred_test,average='macro'))
    acc.append(accuracy_score(y_test,pred_test))
    #ROC_AUC.append(roc_auc_score(y_test, pred_test_probs[:,1]))       
    conf.append(confusion_matrix(y_test,pred_test))
    
test_set_scores = zip(f1,prec,recall,acc,conf)   

test_set_result = pd.DataFrame(test_set_scores, 
                               columns=['F1','precision','recall',
                                        'accuracy','confusion_matrix'], 
                               index = ['LR','DT','SVM','gnb','adaboost','GBDT','xgboost','CatBoost','LightGBM','RF'])
test_set_result.round(4)

# %%
# 特征重要性
# dt_imp = DT.feature_importances_ / sum(DT.feature_importances_)
ada_imp = adaboost.feature_importances_ / np.sum(adaboost.feature_importances_)
gbdt_imp = GBDT.feature_importances_ / np.sum(GBDT.feature_importances_)
xgb_imp = xgboost.feature_importances_ / np.sum(xgboost.feature_importances_)
cat_imp = CatBoost.feature_importances_ / np.sum(CatBoost.feature_importances_)
lgbm_imp = LightGBM.feature_importances_ / np.sum(LightGBM.feature_importances_)
rf_imp =RF.feature_importances_ / np.sum(RF.feature_importances_)


labels = q1_ml.columns[9:23]
x = np.arange(0.5,28.5,2)
w = 0.3
fig, ax = plt.subplots(1, 1, figsize=(24,9),dpi = 600)
r1 = ax.bar(x - 2.5*w, rf_imp, w, label = "RandomForest")
r2 = ax.bar(x - 1.5*w, ada_imp, w, label = "AdaBoost")
r3 = ax.bar(x - 0.5*w, gbdt_imp, w, label = "GBDT")
r4 = ax.bar(x + 0.5*w, xgb_imp, w, label = "XGBoost")
r5 = ax.bar(x + 1.5*w, cat_imp, w, label = "CatBoost")
r6 = ax.bar(x + 2.5*w, lgbm_imp, w, label = "LightGBM")

ax.set_ylabel("Importance", fontdict={'family': 'Times New Roman', 'size': 15})
ax.set_xlabel("Features", fontdict={'family': 'Times New Roman', 'size': 15})
ax.set_xticks(x)
ax.set_xticklabels(labels)
ax.set_title("Importance by Different Models", 
             fontdict={'family': 'Times New Roman', 'size': 15})
ax.legend()

# %%
#铅钡玻璃的风化程度分类
#设置训练集和测试集
X = q1_1.iloc[:,9:23]
y = q1_1.iloc[:,8]

#指定random_state = 88
X_train, X_test, y_train, y_test = train_test_split(X,y,test_size = 0.20, random_state = 88)

# %%
#创建展示结果的展示数据框
test_set_result = pd.DataFrame()
#f1,prec,recall,acc,ROC_AUC,conf = ([],[],[],[],[],[])
f1,prec,recall,acc,conf = ([],[],[],[],[])

#评估不同分类模型的结果
for model_name in ['LR','DT','SVM','gnb','adaboost','GBDT','xgboost','CatBoost','LightGBM','RF']:
    model = eval(model_name)

    model.fit(X_train, y_train.ravel())

    pred_test = model.predict(X_test)
    pred_test_probs = model.predict_proba(X_test)
    #fpr, tpr, thresholds = roc_curve(y_test,pred_test)

    f1.append(f1_score(y_test,pred_test,average='macro'))
    prec.append(precision_score(y_test,pred_test,average='macro'))
    recall.append(recall_score(y_test,pred_test,average='macro'))
    acc.append(accuracy_score(y_test,pred_test))
    #ROC_AUC.append(roc_auc_score(y_test, pred_test_probs[:,1]))       
    conf.append(confusion_matrix(y_test,pred_test))
    
test_set_scores = zip(f1,prec,recall,acc,conf)   

test_set_result = pd.DataFrame(test_set_scores, 
                               columns=['F1','precision','recall',
                                        'accuracy','confusion_matrix'], 
                               index = ['LR','DT','SVM','gnb','adaboost','GBDT','xgboost','CatBoost','LightGBM','RF'])
test_set_result.round(4)

# %%
# 特征重要性
# dt_imp = DT.feature_importances_ / sum(DT.feature_importances_)
ada_imp = adaboost.feature_importances_ / np.sum(adaboost.feature_importances_)
gbdt_imp = GBDT.feature_importances_ / np.sum(GBDT.feature_importances_)
xgb_imp = xgboost.feature_importances_ / np.sum(xgboost.feature_importances_)
cat_imp = CatBoost.feature_importances_ / np.sum(CatBoost.feature_importances_)
lgbm_imp = LightGBM.feature_importances_ / np.sum(LightGBM.feature_importances_)
rf_imp =RF.feature_importances_ / np.sum(RF.feature_importances_)


labels = q1_ml.columns[9:23]
x = np.arange(0.5,28.5,2)
w = 0.3
fig, ax = plt.subplots(1, 1, figsize=(24,9),dpi = 600)
r1 = ax.bar(x - 2.5*w, rf_imp, w, label = "RandomForest")
r2 = ax.bar(x - 1.5*w, ada_imp, w, label = "AdaBoost")
r3 = ax.bar(x - 0.5*w, gbdt_imp, w, label = "GBDT")
r4 = ax.bar(x + 0.5*w, xgb_imp, w, label = "XGBoost")
r5 = ax.bar(x + 1.5*w, cat_imp, w, label = "CatBoost")
r6 = ax.bar(x + 2.5*w, lgbm_imp, w, label = "LightGBM")

ax.set_ylabel("Importance", fontdict={'family': 'Times New Roman', 'size': 15})
ax.set_xlabel("Features", fontdict={'family': 'Times New Roman', 'size': 15})
ax.set_xticks(x)
ax.set_xticklabels(labels)
ax.set_title("Importance by Different Models", 
             fontdict={'family': 'Times New Roman', 'size': 15})
ax.legend()

# %%
#问题二
sum = []
for i in range(9,23):
    y = kruskal(q1_0.iloc[:,i],q1_1.iloc[:,i])
    sum.append(y)
sum

# %%
# 无风化条件下
sum = []
for i in range(9,23):
    y = kruskal(q1_00.iloc[:,i],q1_10.iloc[:,i])
    sum.append(y)
sum

# %%
# 风化条件下
sum = []
for i in range(9,23):
    y = kruskal(q1_01.iloc[:,i],q1_11.iloc[:,i])
    sum.append(y)
sum

# %%
#逻辑回归模型
#LR------------------------------
############################################
LR_tuned_params = {'C': 1, 
                   'penalty': 'l2', 
                   'solver': 'newton-cg'
                  }

LR = LogisticRegression(random_state = 88).set_params(**LR_tuned_params)
#LR------------------------------
############################################

Standard_LR = StandardScaler()
data_standard = pd.DataFrame(Standard_LR.fit_transform(q1.iloc[:,9:23]))

#设置训练集和测试集
X = data_standard
y = q1.iloc[:,-1]

#指定random_state = 88
X_train, X_test, y_train, y_test = train_test_split(X,y,test_size = 0.20, random_state = 88)

LR.fit(X_train, y_train.ravel())

#模型阈值
intercept = LR.intercept_ 

#模型系数
w = LR.coef_[0] 
prob_y = 1/(1+np.exp(-(X_train.dot(w)+intercept)))#dot矩阵乘法

print(intercept,w)

pred_test = LR.predict(X_test)
pred_test_probs = LR.predict_proba(X_test)
fpr, tpr, thresholds = roc_curve(y_test,pred_test)
print(f1_score(y_test,pred_test),
    precision_score(y_test,pred_test),
    recall_score(y_test,pred_test),
    accuracy_score(y_test,pred_test),
    roc_auc_score(y_test, pred_test_probs[:,1]),    
    confusion_matrix(y_test,pred_test))

# %%
#导入问题三测试集
q3 = pd.read_csv("sheet3.csv")
q3_test = q3.iloc[:,2:]
q3_test
#预测结果：01111001

# %%
Standard_LR = StandardScaler()
data_standard = pd.DataFrame(Standard_LR.fit_transform(q1.iloc[:,9:23]))
data_standard.columns = q1.columns[9:23]
data_standard

# %%
def create_data(data):
    a = data.copy()
    for i in range(len(data.columns)):
        for j in range(i, len(data.columns)):
            a[data.columns[i] + "*" + data.columns[j]] = np.array(data.iloc[:, i]) * np.array(data.iloc[:, j])
    return a

# %%
X = data_standard.iloc[:,[2,9]]
y = q1.iloc[:,-1]
data = pd.concat([X,y],axis = 1)
logist = Logit(y.values.ravel(),X)
result = logist.fit(method="lbfgs")
result.summary()

# %%
y_pred = 1/(1+np.exp(-9.9972*X["K2O"]+5.3734*X["BaO"]))
y_pred_class = []
threshold = 0.5
for i in y_pred:
    if (i >=threshold):
        y_pred_class.append(1)
    else:
        y_pred_class.append(0)
y_true = y

accuracy_score(y_pred_class,y_true)

# %%
LR = LogisticRegression(random_state = 88)
#指定random_state = 88
X_train, X_test, y_train, y_test = train_test_split(X,y,test_size = 0.20, random_state = 88)
LR.fit(X_train, y_train.ravel())

pred_test = LR.predict(X)
accuracy_score(y,pred_test)

# %%
from statsmodels.stats.outliers_influence import variance_inflation_factor
# 计算方差膨胀因子
x = np.array(X)
vif_list = [variance_inflation_factor(x, i) for i in range(x.shape[1])]
df_vif = pd.DataFrame({'variable': list(X.columns), 'vif': vif_list})
df_vif = df_vif[~(df_vif['variable'] == 'const')] 
print(df_vif)

# %%
import statsmodels.api as sm
data_create = create_data(data_standard.iloc[:,[0,2,3,6,8,9,11]])
X = data_create[data_create.columns.difference(["CaO*BaO","K2O*Fe2O3","BaO","CaO","Fe2O3*BaO","K2O*SrO","SiO2*CaO","K2O*K2O","SiO2*SiO2",
                                                "BaO*BaO","SiO2*BaO","Fe2O3","SiO2","SrO*SrO","CaO*CaO","SrO","CaO*SrO","K2O*BaO","SiO2*K2O","CaO*Fe2O3","PbO*BaO"])]
y = q1.iloc[:,-1]
data = pd.concat([X,y],axis = 1)
logist = sm.OLS(y.values.ravel(),X)
result = logist.fit()
result.summary()

# %%
y_pred = -0.1257*X["BaO*SrO"]+0.1659*X["CaO*PbO"]+0.0432*X["Fe2O3*Fe2O3"]+0.3404*X["Fe2O3*PbO"]\
        -0.2032*X["Fe2O3*SrO"]-1.9364*X["K2O"]+0.0969*X["K2O*CaO"]-1.4744*X["K2O*PbO"]-0.4693*X["PbO"]\
        +0.3860*X["PbO*PbO"]-0.3229*X["PbO*SrO"]+0.1093*X["SiO2*Fe2O3"]+0.6261*X["SiO2*PbO"]-0.3248*X["SiO2*SrO"]
acc = []
threshold = np.arange(0,1.0,0.05)
for thre in threshold:
    y_pred_class = []
    for i in y_pred:
        if (i >=thre):
            y_pred_class.append(1)
        else:
            y_pred_class.append(0)
    y_true = y
    acc.append(accuracy_score(y_pred_class,y_true))
acc

# %%
#问题三分类
X = create_data(q3_test.iloc[:,[0,2,3,6,8,9,11]])
y_pred = -0.1257*X["BaO*SrO"]+0.1659*X["CaO*PbO"]+0.0432*X["Fe2O3*Fe2O3"]+0.3404*X["Fe2O3*PbO"]\
        -0.2032*X["Fe2O3*SrO"]-1.9364*X["K2O"]+0.0969*X["K2O*CaO"]-1.4744*X["K2O*PbO"]-0.4693*X["PbO"]\
        +0.3860*X["PbO*PbO"]-0.3229*X["PbO*SrO"]+0.1093*X["SiO2*Fe2O3"]+0.6261*X["SiO2*PbO"]-0.3248*X["SiO2*SrO"]
threshold = 0.25
y_pred_class = []
for i in y_pred:
    if (i >=thre):
        y_pred_class.append(1)
    else:
        y_pred_class.append(0)
y_pred_class

# %%
data_standard = pd.DataFrame(Standard_LR.fit_transform(q1[q1.iloc[:,8]==0].iloc[:,9:23]))
data_standard.columns = q1.columns[9:23]
#data_create = create_data(data_standard.iloc[:,[0,8,9,10,11]])
# X = statsmodels.tools.add_constant(data_standard.iloc[:,[8]])
X = data_standard.iloc[:,[8,9]]
y = q1[q1.iloc[:,8]==0].iloc[:,-1]
data = pd.concat([X,y],axis = 1)
logist = Logit(y.values.ravel(),X)
result = logist.fit(method='lbfgs')
result.summary()

# %%
from statsmodels.stats.outliers_influence import variance_inflation_factor
# 计算方差膨胀因子
x = np.array(X)
vif_list = [variance_inflation_factor(x, i) for i in range(x.shape[1])]
df_vif = pd.DataFrame({'variable': list(X.columns), 'vif': vif_list})
df_vif = df_vif[~(df_vif['variable'] == 'const')] 
print(df_vif)

# %%
import statsmodels.api as sm
data_create = create_data(data_standard.iloc[:,[0,2,3,6,8,9,11]])
X = data_create[data_create.columns.difference(["Fe2O3*PbO","K2O*SrO","PbO*PbO","SiO2*SrO","CaO","BaO","K2O*K2O","CaO*PbO","PbO*BaO",
                                                "SrO*SrO","SiO2*K2O"])]
y = q1[q1.iloc[:,8]==0].iloc[:,-1]
data = pd.concat([X,y],axis = 1)
logist = sm.OLS(y.values.ravel(),X)
result = logist.fit()
result.summary()

# %%
y_pred = -0.3908*X["BaO*BaO"]-0.4118*X["BaO*SrO"]-0.5156*X["CaO*BaO"]-0.5953*X["CaO*CaO"]-0.2433*X["CaO*Fe2O3"]-0.2988*X["CaO*SrO"]-0.4241*X["Fe2O3"]\
    -1.1943*X["Fe2O3*BaO"]-0.0507*X["Fe2O3*Fe2O3"]-0.3104*X["Fe2O3*SrO"]-1.3703*X["K2O"]+0.9707*X["K2O*BaO"]+0.5181*X["K2O*CaO"]-0.4021*X["K2O*Fe2O3"]\
    -1.3199*X["K2O*PbO"]-0.7357*X["PbO"]+0.2709*X["PbO*SrO"]-0.4226*X["SiO2"]-1.4151*X["SiO2*BaO"]-1.2138*X["SiO2*CaO"]-0.4715*X["SiO2*Fe2O3"]\
    -0.3110*X["SiO2*PbO"]-0.7662*X["SiO2*SiO2"]-0.5319*X["SrO"]
acc = []
threshold = np.arange(0,1.0,0.05)
for thre in threshold:
    y_pred_class = []
    for i in y_pred:
        if (i >=thre):
            y_pred_class.append(1)
        else:
            y_pred_class.append(0)
    y_true = y
    acc.append(accuracy_score(y_pred_class,y_true))
acc

# %%
q3_test.iloc[[0,2,3,7],[0,2,3,6,8,9,11]]

# %%
X = create_data(q3_test.iloc[[0,2,3,7],[0,2,3,6,8,9,11]])
y_pred = -0.3908*X["BaO*BaO"]-0.4118*X["BaO*SrO"]-0.5156*X["CaO*BaO"]-0.5953*X["CaO*CaO"]-0.2433*X["CaO*Fe2O3"]-0.2988*X["CaO*SrO"]-0.4241*X["Fe2O3"]\
    -1.1943*X["Fe2O3*BaO"]-0.0507*X["Fe2O3*Fe2O3"]-0.3104*X["Fe2O3*SrO"]-1.3703*X["K2O"]+0.9707*X["K2O*BaO"]+0.5181*X["K2O*CaO"]-0.4021*X["K2O*Fe2O3"]\
    -1.3199*X["K2O*PbO"]-0.7357*X["PbO"]+0.2709*X["PbO*SrO"]-0.4226*X["SiO2"]-1.4151*X["SiO2*BaO"]-1.2138*X["SiO2*CaO"]-0.4715*X["SiO2*Fe2O3"]\
    -0.3110*X["SiO2*PbO"]-0.7662*X["SiO2*SiO2"]-0.5319*X["SrO"]
acc = []
threshold = 0.5
y_pred_class = []
for i in y_pred:
    if (i >=thre):
        y_pred_class.append(1)
    else:
        y_pred_class.append(0)
y_pred_class

# %%
data_standard = pd.DataFrame(Standard_LR.fit_transform(q1[q1.iloc[:,8]==1].iloc[:,9:23]))
data_standard.columns = q1.columns[9:23]
# data_create = create_data(data_standard.iloc[:,[0,6,8,9,10,11]])
# X = statsmodels.tools.tools.add_constant(data_create)
X = data_standard.iloc[:,[9,10]]
y = q1[q1.iloc[:,8]==1].iloc[:,-1]
data = pd.concat([X,y],axis = 1)
logist = Logit(y.values.ravel(),X)
result = logist.fit(method='lbfgs')
result.summary()

# %%
from statsmodels.stats.outliers_influence import variance_inflation_factor
# 计算方差膨胀因子
x = np.array(X)
vif_list = [variance_inflation_factor(x, i) for i in range(x.shape[1])]
df_vif = pd.DataFrame({'variable': list(X.columns), 'vif': vif_list})
df_vif = df_vif[~(df_vif['variable'] == 'const')] 
print(df_vif)

# %%
import statsmodels.api as sm
data_standard = pd.DataFrame(Standard_LR.fit_transform(q1[q1.iloc[:,8]==1].iloc[:,9:23]))
data_standard.columns = q1.columns[9:23]
data_create = create_data(data_standard.iloc[:,[0,6,8,9,10,11]])
X = data_create[data_create.columns.difference(["BaO*SrO","Fe2O3","PbO","P2O5","P2O5*SrO","Fe2O3*P2O5","BaO"])]
y = q1[q1.iloc[:,8]==1].iloc[:,-1]
data = pd.concat([X,y],axis = 1)
logist = sm.OLS(y.values.ravel(),X)
result = logist.fit()
result.summary()

# %%
y_pred = 4.2646*X["BaO*BaO"]+1.5279*X["BaO*P2O5"]+2.3950*X["Fe2O3*BaO"]+0.9244*X["Fe2O3*Fe2O3"]+4.6927*X["Fe2O3*PbO"]-0.6408*X["Fe2O3*SrO"]+0.3746*X["P2O5*P2O5"]\
    +17.2158*X["PbO*BaO"]+3.7429*X["PbO*P2O5"]+11.5087*X["PbO*PbO"]+3.7670*X["PbO*SrO"]-2.0583*X["SiO2"]+19.7804*X["SiO2*BaO"]+5.9970*X["SiO2*Fe2O3"]+4.6739*X["SiO2*P2O5"]\
    +36.4042*X["SiO2*PbO"]+23.9542*X["SiO2*SiO2"]+0.7206*X["SiO2*SrO"]-1.5281*X["SrO"]-0.6645*X["SrO*SrO"]

acc = []
threshold = np.arange(0,1.0,0.05)
for thre in threshold:
    y_pred_class = []
    for i in y_pred:
        if (i >=thre):
            y_pred_class.append(1)
        else:
            y_pred_class.append(0)
    y_true = y
    acc.append(accuracy_score(y_pred_class,y_true))
acc

# %%
q3_test.iloc[:,[0,6,8,9,10,11]]

# %%
X = create_data(q3_test.iloc[[1,4,5,6],[0,6,8,9,10,11]])
y_pred = 4.2646*X["BaO*BaO"]+1.5279*X["BaO*P2O5"]+2.3950*X["Fe2O3*BaO"]+0.9244*X["Fe2O3*Fe2O3"]+4.6927*X["Fe2O3*PbO"]\
    -0.6408*X["Fe2O3*SrO"]+0.3746*X["P2O5*P2O5"]+17.2158*X["PbO*BaO"]+3.7429*X["PbO*P2O5"]+11.5087*X["PbO*PbO"]\
    +3.7670*X["PbO*SrO"]-2.0583*X["SiO2"]+19.7804*X["SiO2*BaO"]+5.9970*X["SiO2*Fe2O3"]+4.6739*X["SiO2*P2O5"]\
    +36.4042*X["SiO2*PbO"]+23.9542*X["SiO2*SiO2"]+0.7206*X["SiO2*SrO"]-1.5281*X["SrO"]-0.6645*X["SrO*SrO"]
acc = []
threshold = 0.55
y_pred_class = []
for i in y_pred:
    if (i >=thre):
        y_pred_class.append(1)
    else:
        y_pred_class.append(0)
y_pred_class

# %%
#Step3
#设置训练集和测试集
#全体数据集
X = pd.concat([q1.iloc[:,9:23]],axis = 1)
y = q1.iloc[:,-1]

#指定random_state = 88
X_train, X_test, y_train, y_test = train_test_split(X,y,test_size = 0.20, random_state = 88)

# %%
#LR------------------------------
############################################
# LR_tuned_params = {'C': 1, 
#                    'penalty': 'l2', 
#                    'solver': 'newton-cg'
#                   }

LR = LogisticRegression(random_state = 88)

#LR------------------------------
############################################



#decision_tree--------------------
############################################
# DT_tuned_params = {'criterion':'gini',
#                     'splitter':'random',
#                     'min_samples_leaf':26,
#                     'min_samples_split':70,
#                     'max_features':20
# }
DT = tree.DecisionTreeClassifier(random_state = 88)

#decision_tree--------------------
############################################


#SVM------------------------------
############################################
# SVM_tuned_params = {'C': 1000,
#                     'gamma': 0.0001, 
#                     'kernel': 'rbf',
#                      'probability': True
#                     }
SVM = SVC(random_state=88,probability=True)

#SVM------------------------------
############################################



#贝叶斯分类------------------------
#############################################0
gnb = GaussianNB()

#贝叶斯分类------------------------
#############################################


#AdaBoost--------------
#############################################
# adaboost_tuned_params = {'n_estimators': 250,
#                   'learning_rate': 0.05, 
#                   "algorithm": "SAMME.R"
#                   }

adaboost = AdaBoostClassifier(random_state=88)

#AdaBoost--------------
#############################################

#GBDT----------------------------
############################################
# GBDT_tuned_params = {"max_features":1.0,
#                   "max_depth": None,
#                   "min_samples_leaf" : 2,
#                   "max_depth" : 5,
#                   'learning_rate': 0.08, 
#                   'n_estimators': 100,
#                   "subsample": 0.85
#                   }

GBDT = GradientBoostingClassifier(random_state=88)

#GBDT----------------------------
###############################################



#xgBoost-----------------------------
#####################################################
# xgboost_tuned_params = {"n_estimators" : 250,
#                     "learning_rate": 0.1,
#                     'max_depth':7,
#                     'min_child_weight':5
                  
# }
xgboost = XGBClassifier(random_state=88)

#xgBoost-----------------------------
#####################################################

#CatBoost-------------------------
########################################
# CatBoost_tuned_params = {'depth': 4,
#                         'learning_rate' : 0.1,    
# }

CatBoost = CatBoostClassifier(random_seed=88)

#CatBoost-------------------------
########################################

#LightGBM-------------------------
########################################
# LightGBM_tuned_params = {'n_estimators': 250,

#                     'learning_rate' :0.1
#                   }

LightGBM = lgb.LGBMClassifier(random_seed=88)
#LightGBM-------------------------
########################################




#RF------------------------------
############################################
# RF_tuned_params = {'max_depth': None,
#                    'max_features': 'sqrt',
#                    'min_samples_leaf': 1,
#                    'n_jobs': -1,
#                    'n_estimators': 160,
#                   }

RF = RandomForestClassifier(random_state=88)
#RF------------------------------
############################################

# %%
#创建展示结果的展示数据框
test_set_result = pd.DataFrame()
f1,prec,recall,acc,ROC_AUC,conf = ([],[],[],[],[],[])

#评估不同分类模型的结果
for model_name in ['LR','DT','SVM','gnb','adaboost','GBDT','xgboost','CatBoost','LightGBM','RF']:
    model = eval(model_name)

    model.fit(X_train, y_train.ravel())

    pred_test = model.predict(X_test)
    pred_test_probs = model.predict_proba(X_test)
    fpr, tpr, thresholds = roc_curve(y_test,pred_test)

    f1.append(f1_score(y_test,pred_test))
    prec.append(precision_score(y_test,pred_test))
    recall.append(recall_score(y_test,pred_test))
    acc.append(accuracy_score(y_test,pred_test))
    ROC_AUC.append(roc_auc_score(y_test, pred_test_probs[:,1]))       
    conf.append(confusion_matrix(y_test,pred_test))
    
test_set_scores = zip(f1,prec,recall,acc,ROC_AUC,conf)   

test_set_result = pd.DataFrame(test_set_scores, 
                               columns=['F1','precision','recall',
                                        'accuracy','ROC_AUC','confusion_matrix'], 
                               index = ['LR','DT','SVM','gnb','adaboost','GBDT','xgboost','CatBoost','LightGBM','RF'])
test_set_result.round(4)

# %%
# 特征重要性
# dt_imp = DT.feature_importances_ / sum(DT.feature_importances_)
ada_imp = adaboost.feature_importances_ / np.sum(adaboost.feature_importances_)
gbdt_imp = GBDT.feature_importances_ / np.sum(GBDT.feature_importances_)
xgb_imp = xgboost.feature_importances_ / np.sum(xgboost.feature_importances_)
cat_imp = CatBoost.feature_importances_ / np.sum(CatBoost.feature_importances_)
lgbm_imp = LightGBM.feature_importances_ / np.sum(LightGBM.feature_importances_)
rf_imp =RF.feature_importances_ / np.sum(RF.feature_importances_)


#labels = np.hstack([["表面风化"],np.array(q1.columns[9:23])]) 
labels = q1.columns[9:23]
x = np.arange(0.5,28.5,2)
w = 0.3
fig, ax = plt.subplots(1, 1, figsize=(24,9),dpi = 600)
r1 = ax.bar(x - 2.5*w, rf_imp, w, label = "RandomForest")
r2 = ax.bar(x - 1.5*w, ada_imp, w, label = "AdaBoost")
r3 = ax.bar(x - 0.5*w, gbdt_imp, w, label = "GBDT")
r4 = ax.bar(x + 0.5*w, xgb_imp, w, label = "XGBoost")
r5 = ax.bar(x + 1.5*w, cat_imp, w, label = "CatBoost")
r6 = ax.bar(x + 2.5*w, lgbm_imp, w, label = "LightGBM")

ax.set_ylabel("Importance", fontdict={'family': 'Times New Roman', 'size': 15})
ax.set_xlabel("Features", fontdict={'family': 'Times New Roman', 'size': 15})
ax.set_xticks(x)
ax.set_xticklabels(labels)
ax.set_title("Importance by Different Models", 
             fontdict={'family': 'Times New Roman', 'size': 15})
ax.legend()

# %%
#设置训练集和测试集
#全体数据集
X = q1[q1.iloc[:,8]==1].iloc[:,9:23]
y = q1[q1.iloc[:,8]==1].iloc[:,-1]

#指定random_state = 88
X_train, X_test, y_train, y_test = train_test_split(X,y,test_size = 0.20, random_state = 88)

# %%
#创建展示结果的展示数据框
test_set_result = pd.DataFrame()
f1,prec,recall,acc,ROC_AUC,conf = ([],[],[],[],[],[])

#评估不同分类模型的结果
for model_name in ['LR','DT','SVM','gnb','adaboost','GBDT','xgboost','CatBoost','LightGBM','RF']:
    model = eval(model_name)

    model.fit(X_train, y_train.ravel())

    pred_test = model.predict(X_test)
    pred_test_probs = model.predict_proba(X_test)
    fpr, tpr, thresholds = roc_curve(y_test,pred_test)

    f1.append(f1_score(y_test,pred_test))
    prec.append(precision_score(y_test,pred_test))
    recall.append(recall_score(y_test,pred_test))
    acc.append(accuracy_score(y_test,pred_test))
    ROC_AUC.append(roc_auc_score(y_test, pred_test_probs[:,1]))       
    conf.append(confusion_matrix(y_test,pred_test))
    
test_set_scores = zip(f1,prec,recall,acc,ROC_AUC,conf)   

test_set_result = pd.DataFrame(test_set_scores, 
                               columns=['F1','precision','recall',
                                        'accuracy','ROC_AUC','confusion_matrix'], 
                               index = ['LR','DT','SVM','gnb','adaboost','GBDT','xgboost','CatBoost','LightGBM','RF'])
test_set_result.round(4)

# %%
X_test = q3.iloc[[1,4,5,6],2:]
for model_name in ['LR','DT','SVM','gnb','adaboost','GBDT','xgboost','CatBoost','LightGBM','RF']:
    model = eval(model_name)
    pred_test = model.predict(X_test)
    print(pred_test)

# %%
# 特征重要性
# dt_imp = DT.feature_importances_ / sum(DT.feature_importances_)
ada_imp = adaboost.feature_importances_ / np.sum(adaboost.feature_importances_)
gbdt_imp = GBDT.feature_importances_ / np.sum(GBDT.feature_importances_)
xgb_imp = xgboost.feature_importances_ / np.sum(xgboost.feature_importances_)
cat_imp = CatBoost.feature_importances_ / np.sum(CatBoost.feature_importances_)
lgbm_imp = LightGBM.feature_importances_ / np.sum(LightGBM.feature_importances_)
rf_imp =RF.feature_importances_ / np.sum(RF.feature_importances_)


labels = q1.columns[9:23]
x = np.arange(0.5,28.5,2)
w = 0.3
fig, ax = plt.subplots(1, 1, figsize=(24,9),dpi = 600)
r1 = ax.bar(x - 2.5*w, rf_imp, w, label = "RandomForest")
r2 = ax.bar(x - 1.5*w, ada_imp, w, label = "AdaBoost")
r3 = ax.bar(x - 0.5*w, gbdt_imp, w, label = "GBDT")
r4 = ax.bar(x + 0.5*w, xgb_imp, w, label = "XGBoost")
r5 = ax.bar(x + 1.5*w, cat_imp, w, label = "CatBoost")
r6 = ax.bar(x + 2.5*w, lgbm_imp, w, label = "LightGBM")

ax.set_ylabel("Importance", fontdict={'family': 'Times New Roman', 'size': 15})
ax.set_xlabel("Features", fontdict={'family': 'Times New Roman', 'size': 15})
ax.set_xticks(x)
ax.set_xticklabels(labels)
ax.set_title("Importance by Different Models", 
             fontdict={'family': 'Times New Roman', 'size': 15})
ax.legend()

# %%
#设置训练集和测试集
#全体数据集
X = q1[q1.iloc[:,8]==0].iloc[:,9:23]
y = q1[q1.iloc[:,8]==0].iloc[:,-1]

#指定random_state = 88
X_train, X_test, y_train, y_test = train_test_split(X,y,test_size = 0.20, random_state = 48)

# %%
#LR------------------------------
############################################
# LR_tuned_params = {'C': 1, 
#                    'penalty': 'l2', 
#                    'solver': 'newton-cg'
#                   }

LR = LogisticRegression(random_state = 88)

#LR------------------------------
############################################



#decision_tree--------------------
############################################
# DT_tuned_params = {'criterion':'gini',
#                     'splitter':'random',
#                     'min_samples_leaf':26,
#                     'min_samples_split':70,
#                     'max_features':20
# }
DT = tree.DecisionTreeClassifier(random_state = 88)

#decision_tree--------------------
############################################


#SVM------------------------------
############################################
# SVM_tuned_params = {'C': 1000,
#                     'gamma': 0.0001, 
#                     'kernel': 'rbf',
#                      'probability': True
#                     }
SVM = SVC(random_state=88,probability=True)

#SVM------------------------------
############################################



#贝叶斯分类------------------------
#############################################0
gnb = GaussianNB()

#贝叶斯分类------------------------
#############################################


#AdaBoost--------------
#############################################
# adaboost_tuned_params = {'n_estimators': 250,
#                   'learning_rate': 0.05, 
#                   "algorithm": "SAMME.R"
#                   }

adaboost = AdaBoostClassifier(random_state=88)

#AdaBoost--------------
#############################################

#GBDT----------------------------
############################################
# GBDT_tuned_params = {"max_features":1.0,
#                   "max_depth": None,
#                   "min_samples_leaf" : 2,
#                   "max_depth" : 5,
#                   'learning_rate': 0.08, 
#                   'n_estimators': 100,
#                   "subsample": 0.85
#                   }

GBDT = GradientBoostingClassifier(random_state=88)

#GBDT----------------------------
###############################################



#xgBoost-----------------------------
#####################################################
# xgboost_tuned_params = {"n_estimators" : 250,
#                     "learning_rate": 0.1,
#                     'max_depth':7,
#                     'min_child_weight':5
                  
# }
xgboost = XGBClassifier(random_state=88)

#xgBoost-----------------------------
#####################################################

#CatBoost-------------------------
########################################
# CatBoost_tuned_params = {'depth': 4,
#                         'learning_rate' : 0.1,    
# }

CatBoost = CatBoostClassifier(random_seed=88)

#CatBoost-------------------------
########################################

#LightGBM-------------------------
########################################
# LightGBM_tuned_params = {'n_estimators': 250,

#                     'learning_rate' :0.1
#                   }

LightGBM = lgb.LGBMClassifier(random_seed=88)
#LightGBM-------------------------
########################################




#RF------------------------------
############################################
# RF_tuned_params = {'max_depth': None,
#                    'max_features': 'sqrt',
#                    'min_samples_leaf': 1,
#                    'n_jobs': -1,
#                    'n_estimators': 160,
#                   }

RF = RandomForestClassifier(random_state=88)
#RF------------------------------
############################################

# %%
#创建展示结果的展示数据框
test_set_result = pd.DataFrame()
f1,prec,recall,acc,ROC_AUC,conf = ([],[],[],[],[],[])

#评估不同分类模型的结果
for model_name in ['LR','DT','SVM','gnb','adaboost','GBDT','xgboost','CatBoost','LightGBM','RF']:
    model = eval(model_name)

    model.fit(X_train, y_train.ravel())

    pred_test = model.predict(X_test)
    pred_test_probs = model.predict_proba(X_test)
    fpr, tpr, thresholds = roc_curve(y_test,pred_test)

    f1.append(f1_score(y_test,pred_test))
    prec.append(precision_score(y_test,pred_test))
    recall.append(recall_score(y_test,pred_test))
    acc.append(accuracy_score(y_test,pred_test))
    ROC_AUC.append(roc_auc_score(y_test, pred_test_probs[:,1]))       
    conf.append(confusion_matrix(y_test,pred_test))
    
test_set_scores = zip(f1,prec,recall,acc,ROC_AUC,conf)   

test_set_result = pd.DataFrame(test_set_scores, 
                               columns=['F1','precision','recall',
                                        'accuracy','ROC_AUC','confusion_matrix'], 
                               index = ['LR','DT','SVM','gnb','adaboost','GBDT','xgboost','CatBoost','LightGBM','RF'])
test_set_result.round(4)

# %%
X_test = q3.iloc[[0,2,3,7],2:]
for model_name in ['LR','DT','SVM','gnb','adaboost','GBDT','xgboost','CatBoost','LightGBM','RF']:
    model = eval(model_name)
    pred_test = model.predict(X_test)
    print(pred_test)

# %%
# 特征重要性
# dt_imp = DT.feature_importances_ / sum(DT.feature_importances_)
ada_imp = adaboost.feature_importances_ / np.sum(adaboost.feature_importances_)
gbdt_imp = GBDT.feature_importances_ / np.sum(GBDT.feature_importances_)
xgb_imp = xgboost.feature_importances_ / np.sum(xgboost.feature_importances_)
cat_imp = CatBoost.feature_importances_ / np.sum(CatBoost.feature_importances_)
lgbm_imp = LightGBM.feature_importances_ / np.sum(LightGBM.feature_importances_)
rf_imp =RF.feature_importances_ / np.sum(RF.feature_importances_)


labels = q1.columns[9:23]
x = np.arange(0.5,28.5,2)
w = 0.3
fig, ax = plt.subplots(1, 1, figsize=(24,9),dpi = 600)
r1 = ax.bar(x - 2.5*w, rf_imp, w, label = "RandomForest")
r2 = ax.bar(x - 1.5*w, ada_imp, w, label = "AdaBoost")
r3 = ax.bar(x - 0.5*w, gbdt_imp, w, label = "GBDT")
r4 = ax.bar(x + 0.5*w, xgb_imp, w, label = "XGBoost")
r5 = ax.bar(x + 1.5*w, cat_imp, w, label = "CatBoost")
r6 = ax.bar(x + 2.5*w, lgbm_imp, w, label = "LightGBM")

ax.set_ylabel("Importance", fontdict={'family': 'Times New Roman', 'size': 15})
ax.set_xlabel("Features", fontdict={'family': 'Times New Roman', 'size': 15})
ax.set_xticks(x)
ax.set_xticklabels(labels)
ax.set_title("Importance by Different Models", 
             fontdict={'family': 'Times New Roman', 'size': 15})
ax.legend()

# %%
plotdata = pd.read_csv("sheet2_nw.csv")
plotdata

# %%
sns.kdeplot(data = plotdata[plotdata.iloc[:,8] == 0].iloc[:,10],label = "变换后无风化SiO2含量",color = "#B897EC")
plt.legend()
plt.title("C$_{0}$'分布")

# %%
sns.kdeplot(data = q1[q1.iloc[:,8] == 0].iloc[:,10],label = "变换前无风化SiO2含量",color = "#B897EC")
plt.legend()
plt.title("C$_{0}$分布")

# %%
sns.kdeplot(data = plotdata[plotdata.iloc[:,8] == 1].iloc[:,10],label = "变换后风化SiO2含量",color = "#FB93D9")
plt.legend()
plt.title("C$_{1}$分布")

# %%
sns.kdeplot(data = q1[q1.iloc[:,8] == 1].iloc[:,10],label = "变换前风化SiO2含量",color = "#FB93D9")
plt.legend()
plt.title("C$_{1}$分布")

# %%
sns.kdeplot(data = plotdata[plotdata.iloc[:,8] == 0].iloc[:,10],label = "变换后无风化SiO2含量",color = "#B897EC")
plt.legend()
# plt.title("C0'分布")
sns.kdeplot(data = plotdata[plotdata.iloc[:,8] == 1].iloc[:,10],label = "变换后风化SiO2含量",color = "#FB93D9")
plt.legend()
# plt.title("C1'分布")

# %%
q1

# %%
ax = plt.figure(figsize = (12,8))
ax = plt.subplot(projection = '3d') 
ax = plt.scatter(q1_0["SiO2"], q1_0["MgO"],q1_0["K2O"], c = 'r' )
plt.title("高钾玻璃")
plt.legend()
# plt.scatter(q1_1["SiO2"], q1_1["PbO"],q1_1["P2O5"], c = 'b' )  

# %%
ax = plt.figure(figsize = (12,8))
ax = plt.subplot(projection = '3d') 
ax = plt.scatter(q1_1["SiO2"], q1_1["MgO"],q1_1["K2O"], c = 'r' )
plt.title("高钾玻璃")
plt.legend()


